function [v,iv]= subVector(v0,num_v)
% generate a sub-vector by randomly sampling elements from a given vector

% Inputs:
%  v0: a vector;
%  num_v: length of the subvector;
% Outputs:
%  v: the generated subvector;
%  iv: indexing the elements of subvector, v = v0(iv);
len_v0 = length(v0);
if len_v0<=num_v
    v = v0;    
    iv = sameShape(v0,1:len_v0);
else
    iv = randi_unique(len_v0,num_v);
    iv = sameShape(v0,iv);
    v = v0(iv);
end


end



function v2 = sameShape(v0,v2)
% make v2 a column vector if v0 is column vector, make v2 row vector, if v0
%   is row vector;
if xor(isColumnVector(v2),isColumnVector(v0))
    v2 = v2';
end
end