function flag = isinteger_str(str)
% check whether a string is composed of a single integer
%   composed by numbers 0--9,  '+', '-'
%   ('+','-s' only occur at the beginning);
flag = ~isempty(regexp(str,'^[-+]?[\d]+$','match'));

end