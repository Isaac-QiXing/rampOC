function [model] = targetRank_basic_theta(argData,argAlg)
% Identify the reliable targets by viewing the weights theta as variable of
%  the model
%
% Inputs 
%  argData: the argument structure about data
%   .X: matrix of n-by-m, each row consists a sample, i.e.
%          X consists of n samples and m characteristics;
%   .y: a column vector with length n, consisting the label of the samples;
%     1: the targets, -1: decoys
%   .dataFile: Optional, data file name, containing the variable of 
%       X: the same meaning as arg.X
%       y: the same meaning as arg.y
%       sizeX: a 2-by-1 vector, inicating the number of rows and columns of
%         data matrix X
%       Users can set arg.X and arg.y, or   arg.dataFile; but for large scale
%       problem, arg.dataFile is recommended for efficiency use of memory;
%  argAlg: the argument structure about algorithm;
%   .kernelType: kernel name;
%   .r1: value of kernel argument;
%   .c1: the weight for the training error;
%   .c2: the weight for encouraging the number of PSMs;
%   .w: Optional, a vector of feature weights, with length equal the number
%       of features; default []: all features are set weight 1.0;
%   .theta_target: Optional, a column vector with length nnz(y==1), which
%     indicates the initial weights of the targets, default 0.1;
%   .tolFun_foapl: tolerance of iterated function values
% Outputs
%  model: the model structure
%   .f: the discriminent function: f: R^q --> R:  x--> y;
%   .alpha, 
%   .b:  the discriminat function:
%                 f(x) = \sum_{i} \alpha_i k(x_i, x) + b;
%   .theta_index: a column vector consisting the indices of the
%        nonzero weights of the targets;
%   .theta: the nonzero weights of the targets;
%        i.e. sol.theta_index(i) = 3;
%             sol.theta(i) = 1.0; means that the 3rd sample (corresponding
%             y(3) )  is target (i.e. y(3)==1), and its weights is solved
%             to be 1.0;


% arguments
[X,y,dataFile] = getArgument(argData,{'X','y','dataFile'});

if isempty(X) || isempty(y)
    if isempty(dataFile)
        error('Either arg.X, arg.y or arg.dataFile should be set.\n');
    else
        load(dataFile,'X','y');        
    end    
end

[kernelType,r1,c1,c2,w,theta_target,tolFun_foapl] = getArgument(argAlg,...
    {'kernelType','r1','c1','c2','w','theta_target','tolFun_foapl'});

% [svm_theta_solver] = problemArg('svm_theta_solver');
[flag_low_rank_approx,verbose]= problemArg('flag_low_rank_approx','verbose');
tol = problemArg('tol_low_rank_approx');
 
if flag_low_rank_approx   
    GK_str = 'G';
else
    GK_str = 'K';    
end


% set theta_target  and arguments arg
n_target = nnz(y==1);
if ~isempty(theta_target) && length(theta_target)~=n_target
    warning('the length of theta_target do not coincide with the number of targets.');
end
if  (isempty(theta_target) || length(theta_target)~=n_target)
    theta_target = 0.1*ones(n_target,1);
end
arg = struct('c1',c1,'c2',c2,'theta_target',theta_target,'GK',GK_str,'tolFun_foapl',tolFun_foapl);

% calculate the kernel matrix K or its Cholesky factor matrix G
if flag_low_rank_approx
    arg_chol = struct('kernelType',kernelType,'r1',r1,'tol',tol,'w',w);
    [G r]= chol_kernel_matrix(X,arg_chol);
    if verbose>=3
        fprintf(1,'Finished to do Cholesky factorization of the kernel matrix.\n');
        fprintf(1,'The rank of the Cholesky matrix: r = %d \n',r);
    end    
else
    K = kernelMatrix_OnceaLine(kernelType,X',X',r1,w);
end


% solve the nonlinear programming for classification  
  % -------- in current version, matlab built-in solver is employed;  
%switch lower(svm_theta_solver)
%    case 'matlabbuildin'
        if flag_low_rank_approx
            [model] = primal_SVM_theta(arg,G,y); 
        else
            [model] = primal_SVM_theta(arg,K,y); 
        end
%end

model.f = @discriminant;
epsilon = 1.0E-10;
id_alpha = abs(model.alpha)>=epsilon;
Y = X(id_alpha,:)';

% clear variables
clear('X','y');
if flag_low_rank_approx
    clear('G');
else
    clear('K');
end

    function fx = discriminant(X1)
        % the classification function R^q --> R
        % Inputs:
        %   X1: a matrix with each row indicating  a sample of PSM,
        %       i.e. X1 is a matrix with q columns
        % Outputs:
        %   fx: a column vector containing the discriminat function values 
        %         of the input samples;        
        % f(x) = \sum_{i} \alpha_i k(x_i, x) + b;

        %K1 = kernelMatrix_OnceaLine(kernelType,X1',X(id_alpha,:)',r1,w);
        K1 = kernelMatrix_OnceaLine(kernelType,X1',Y,r1,w);
        fx = K1*model.alpha(id_alpha) + model.b;
    end
    
end
