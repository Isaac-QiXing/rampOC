function varargout = gather_v(flag_double,varargin)
%Transfer  a group of gpuArrays to local workspace
% Inputs:
%  flag_double: 1 or 0, indicate whether to return numeric arrays of double float  type
%  varargin{}: numeric  arrays of gpuArray type
% Outputs:
%   the transformed arrays 
% Usage: 
%   [a,b] = gather_v(1,gpuArray(zeros(2,2)),gpuArray([1,2,3]));
%       a,b are numeric array, with 
%       a = zeros(2,2,'double')
%       b = [1,2,3] with double type 

varargout = cell(size(varargin));
if nargin>1
    for ii=1:nargin-1
        if flag_double
            varargout{ii} = double(gather(varargin{ii}));
        else
            varargout{ii} = gather(varargin{ii});
        end
    end
end

end