function [enz]= enzNC(peptide_str)
% identify the N terminus and C terminus of the given peptide 
% Inputs:
% peptide_str: the character array of the given peptide, e.g.
%      'K.HSLAESIQNAGILQSYWENEIPQKK.S'
% Outputs:
% enz: a 1-by-2 row vector;
%   enz(1): 0 or 1, is the peptide preceded by a tryptic  site?
%   enz(2): 0 or 1, does the peptide have a tryptic c_terminus? 
% Note:
%   tryptic  site:  K or R residue;

peptide_str = strtrim(peptide_str);
char_split = '.'; % character to split the peptide array
p_array = strfind(peptide_str,char_split);
% get the first and the last position of the char_split
len_p_array = length(p_array);
p_l = 0; p_r = 0;
if len_p_array==1
    p = p_array(1);
    if p==2
        p_l = p;
    elseif p==length(peptide_str)-1
        p_r = p;
    end
elseif len_p_array>=2
    p_l = p_array(1);
    p_r = p_array(len_p_array);
end

% get the C and N terminal residues
N_residue = '';
C_residue = '';
if p_l>1 
    N_residue = peptide_str(p_l-1);
end
if p_r>1 %&& p_r<length(peptide_str)  
    %C_residue = peptide_str(p_r+1);
    C_residue = peptide_str(p_r-1);
end

% identify the peptide style
enz = [0,0];
if strcmpi(N_residue, 'K') || strcmpi(N_residue, 'R')
    enz(1) = 1;
end    

if strcmpi(C_residue,'K') ||strcmpi(C_residue,'R')    
    enz(2) = 1;    
end

end

