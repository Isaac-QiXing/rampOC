function parent_dir = parentDir(dir_str,arg)
% get the parent directory 
% Inputs:
%   dir_str: a path string splitted by '/' or '\';
%   arg: Optional, argument structure;
%     .depth: Optional, a nonnegative integer indicating the depth of the
%           parent directory;   default 1. 
%           E.g. if 1: get the parent of the given directory;
%                   2: get the parent of the parerent of the given
%                   directory;
%     .flag_reserve_split_char: Optional, 1 or 0, whether reseve the
%   	splitting charactier '/' (or '\') at the end of the parent_dir;
%   	default 1; 
%   
% complete the argument structe with default values
if ~exist('arg','var')
    arg = struct();
end
    
arg = completeArg(arg,{'depth','flag_reserve_split_char'},{1,1});
parent_dir = '';

if arg.depth<-1
    error('The depth argument should be a nonnegative integer.');
end

dir_str = strtrim(dir_str);
pos_v = regexp(dir_str,'[/\\]','start');
len_pos_v = length(pos_v);
if len_pos_v>0 && pos_v(len_pos_v)==length(dir_str)
    % the last character of DIR_STR is '/' or '\'
    gap_s = 0;
else
    gap_s = 1;
end

ind = len_pos_v-arg.depth+gap_s;
if ind > 0 && ind<=len_pos_v
    ind_str = pos_v(ind); 
elseif   ind> len_pos_v % arg.depth ==0, gap_s ==1
    if ~arg.flag_reserve_split_char
        parent_dir = dir_str;
    else        
        parent_dir = [dir_str dir_str(pos_v(1))]; % append 
    end
    return;
else % ind <0
    return;      % parent_dir is empty directory
end

if arg.flag_reserve_split_char
    parent_dir = dir_str(1:ind_str);
else
    if ind_str>1
        parent_dir = dir_str(1:ind_str-1); % -1: exclude the '\' or '/' char at end
    end
end

end