function saveData(fileName,varargin)
%#function save
% save data to a specified file
% for i=1,2,...
%   varargin{2*i-1}: the varaible name
%   varargin{2*i}: the varaible value
%   the last inputs can also be the parameters: 
%           
% usage                                                                            
%  A1=ones(2,2); B1 = 1:5;     
%   saveData(matFileName, 'A',A1, 'B',B1);    
 
str = '';

for ii=1:floor((nargin-1)/2)
    eval(sprintf('%s=varargin{2*ii};',varargin{2*ii-1}));
    str = sprintf('%s,''%s''',str,varargin{2*ii-1});
end

if ~isempty(str)
    eval(sprintf('save(''%s''%s);',fileName,str));
else
    warning('Both the variable name and value is needed.');
end

end