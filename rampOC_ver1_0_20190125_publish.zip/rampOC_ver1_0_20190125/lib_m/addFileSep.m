function path_str1 = addFileSep(path_str)
% add filesep to the end of a directory string if it does not exist the
% filesep ('/' or '\')

path_str1 = path_str;
if ~isempty(path_str)
    path_str=strtrim(path_str);    
    end_char = path_str(length(path_str));
    if end_char~='\' && end_char~='/'
        path_str1 = [path_str1 filesep];
    end
end

end