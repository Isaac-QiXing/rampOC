function len_v = peptide_length(peptide_cell)
% calculate the number of amino acids of peptide strings
%  Eg. 'A.YLHTNE[160.14].A': length 8;
%      'G.NMTCYLH.K':        length 9;
% Inputs:
%  peptide_cell: cell array of peptide strings;
%       each peptide string has the format
%           Z.ZZZZZ.Z
%       with Z a letter indicating a amino acid;
%       all the strings in `[***]' will be ignored;
%       e.g., 'A.YLHTNE[160.14].A' will be viewed as the same as
%              'A.YLHTNE.A'
% Outputs:
%  len_v: a column vector with the same length as peptide_cell,
%       indicating the number of amino acides of each peptide string;

pattern = '\[[^\]]+]';
[start_c,end_c]= regexp(peptide_cell,pattern,'start','end');
len_v = columnVec(cellfun(@length,peptide_cell,'UniformOutput',true))-2; 
            % -2: the two dots   " *.***.* "
% deal with the `[***]' string
modification_ind = find(cellfun(@(x) ~isempty(x),start_c,'UniformOutput',true));
for ii=1:length(modification_ind)
    k = modification_ind(ii);
    len_v(k) = len_v(k) - ( sum(end_c{k}) - sum(start_c{k}) + length(end_c{k}));
end

end