function [w, varargout] = feature_weight_SVM(arg,varargin)
%   determine the feature weights for SVM classification
%  
% Inputs:
%     arg:  
%        arg.dataFile: Optional, indicating the data file name containing X
%           and y:
%           X: l-by-m matrix, consisting of the samples, with l the
%             number of samples and m the number of features;
%           y: -1 or 1, indicate the label of the sample
%           If arg.dataFile is not set, then varargin{1} and varargin{2}
%             are necessary to set X and y, resp.
%        arg.c:   structral parameter of SVM, a positive scalar,
%        arg.w0: Optional, the initial feature weights
%        arg.beta0: Optional, the initial beta
%   varargin{1}: Optional, the matrix X;
%   varargin{2}: Optional, column vector y; varargin{1} and varargin{2} are
%         necessary if and only if arg.dataFile is not set;
%   
% Outputs:
%   w: a column vector with length m, the weights of the features;
%   varargout{1}: the solution structure sol: 
%      sol.beta: a column vector; 
%      sol.b:  a number;
%      the discriminat function:
%                 f(x) = \sum_{i} \alpha_i k(x_i, x) + b;
%
%
% Reference. sovle a SVM in the primal:
% [1] O. Chapelle. Training a Support Vector Machine in the primal. Neural
% Computaition. 19(5):1155--1178, 2007.


% solve the program:
%
%   min_{beta,w}  <beta, K(w)*beta> + c*\sum_{i=1}^{l} L(y_i,x_i)
%       
%   where  L(y_i,x_i) = { max(0,1-y_i*K_i'*beta) }^2, K_i is the i-th
%   column of K(w), K(w) is a l-by-l matrix depends on w;
%    Currently, we choose the Gaussian kernel:
%       K(w)_{ij} = exp[- 0.5* sum_{k=1}^{m} w_{k}^{2}||x_i(k)-x_j(k)||^2 ]


% Inputs

[dataFile, c1, w0, beta0] = getArgument(arg,{'dataFile','c','w0','beta0'});  
  
[verbose max_ite]= problemArg('verbose','max_ite_feature_weight');

if ~isempty(dataFile)
    load(dataFile,'X','y');
else
    X = varargin{1};
    y = varargin{2};
end


[l m] = size(X);

if l~= length(y)
    error('the size of y and X is not consistent.');
end
% assign Kw for calculating the kernel matrix
Kw = zeros(l,l,m);
 % Kw(i,j,:) = -0.5*(X(i,:)-X(j,:)).^2
ones_l = ones(l,1);
for ii=1:l
    Kw(ii,:,:) = (ones_l*X(ii,:) - X).^2; 
end
Kw = -0.5*Kw;

K= zeros(l,l); % kernel matrix
K_temp = zeros(l,l);
K_grad = zeros(l,l,m); 
  % K_grad(i,j) = k_{ij}(w)';
K_h_w = zeros(l,l,m);  

K_grad_beta = zeros(l,m);
K_h_w_beta = zeros(l,m);

    function cal_K(w)        
        % calculate the kernel matrix K with feature weights w, and the 
        %   gradients of the kernels K_grad
        
          % calulate kernel matrix K
        K = squeeze(multiArray(Kw,w,[3,1]));
        K = exp(K);
          % calculate K_grad 
        for jj = 1:m  
            K_grad(:,:,jj) = Kw(:,:,jj).* K;
        end
    end

    function K_hession_multi_w(w2)
        % multiply the Hessian of K and a weights vector w2
        %  the Hessian of K: K_h
        %   K_h(i,j,:,:) = Hessian(k(w))
        % Note that the gradients K_grad should be calculated beforehand;
        K_temp = squeeze(multiArray(Kw,w2,[3,1]));
        for jj = 1:m  
            K_h_w(:,:,jj) = K_grad(:,:,jj).* K_temp;
        end        
    end

  % objective function
    function [fx gd ] = fun(x)
        x = columnVec(x); % ensure that x is a column vector
        beta1 = x(1:l);
        w1 = x(l+1:l+m); % the weights of the features
             
        % function value
        cal_K(w1); % calcuate the kernel matrix K and gradients K_grad              
        z = K*beta1;
        fx = sum(beta1.*z) + c1*sum(max(0,1-y.*z).^2);            
        % the gradient        
        sv = find(1- y.*z>0); % sv: indices of support vectors          
        K_grad_beta = squeeze(multiArray(K_grad,beta1,[1,1]));
        w_grad1 =  (beta1'*K_grad_beta)'; 
          % w_grad1 = K_grad * beta1 * beta1
        w_grad2 =  2*c1*((z(sv)-y(sv))'*K_grad_beta(sv,:))';
          
        gd = [2*(z +c1*K(:,sv)*(z(sv)-y(sv)) ); % partial differential about beta;
               w_grad1 + w_grad2             ];
                               % partial differential about w   
    end 

    function w = HessMultFcn(x,lambda,v)
        % the Hession matrix at x multiply a vector v
        %              w = H*v,
        % where H is the Hessian at of the Lagrange function at x,
        %   lambda is the Lagrange multiplier (computed by fmincon), 
        %   and v is a vector. 
        % Note that  the syntax for the trust-region-reflective algorithm
        %    does not involve lambda: w = HessMultFcn(H,v)
        
        beta1 = x(1:l);
        w1 = x(l+1:l+m);        
        beta2 = v(1:l);
        w2 = v(l+1:l+m);
        
        cal_K(w1); % calcuate the kernel matrix K and gradients K_grad
        
        z1 = K*beta1;
        sv = find(1-y.*z1>0); % sv: indices of support vectors        
        
    %  1) calculate w11 := H_{beta,beta}*beta2, H_{beta,beta} denotes the
    %    second order gradient of objective function f to the first
    %    argument        
        z2 = K*beta2;
        if ~isempty(sv)
            w11 = 2*(z2+c1*K(:,sv)*z2(sv)); 
        else
            w11 = 2*z2;
        end
    %  2) calculate w12 := H_{beta,w}*w2, H_{beta,w} denotes the
    %    second order gradient of objective function f first to the 2nd
    %    argument, w, then to the first one, beta;
        K_grad_beta = squeeze(multiArray(K_grad,beta1,[1,1]));
        if ~isempty(sv)
            K_grad_y = squeeze(multiArray(K_grad(:,sv,:),y(sv),[2,1]));        
        end
        k_g_w2 = K_grad_beta*w2;
        if ~isempty(sv)             
            w12 = 2*k_g_w2 ...
                + 2*c1*(squeeze(multiArray(K_grad(sv,:,:),z1(sv),[1,1]))*w2) ...
                + 2*c1*(K(:,sv)*k_g_w2(sv)) ...
                - 2*c1*(K_grad_y*w2) ;
        else
            w12 = 2*k_g_w2;
        end
    % 3) calculate w21:= H_{w,beta}*beta2
        if ~isempty(sv)>0             
            w21 = 2* (beta2'*K_grad_beta)' ...
                + 2*c1*(z1(sv)'* squeeze(multiArray(K_grad(:,sv,:),beta2,[1,1])) )'...                
                + 2*c1*(z2(sv)'*K_grad_beta(sv,:))'...
                - 2*c1*(beta2'*K_grad_y)';
        else
            w21 = 2*(beta2'*K_grad_beta)';
        end
    % 4) w22:= H_{w,w}*w2 
        K_hession_multi_w(w2); % calculate K_h_w
        K_h_w_beta = squeeze(multiArray(K_h_w,beta1,[1,1]));
        w22 = (beta1'*K_h_w_beta)' ...
              + 2*c1*( k_g_w2(sv)'*K_grad_beta(sv,:))'...
              + 2*c1*((z1(sv)-y(sv))'*K_h_w_beta(sv,:))';
        
        w = [w11+w12; w21+w22];  
    end % end the function HessMultFcn()
    

    % initial point   
    if isempty(beta0)
        beta0= zeros(l,1);
    end
    if isempty(w0)
        w0 = ones(m,1); 
    else
        w0 = w0.^2; % we view w^2 as a variable to determine
    end
    x0  = [beta0; w0];
   
    A = [];
    b = [];
    Aeq = []; 
    beq = []; 
    lb = [-Inf*ones(l,1);
           zeros(m,1)];
    ub = [Inf*ones(l,1);
           Inf(m,1)];
    nonlcon = [];
    options = optimset('TolFun',1e-6,'MaxFunEvals',max(max_ite(1)*l,max_ite(2)),... 
        'GradObj','on','Algorithm','interior-point',...
        'Hessian','user-supplied','SubproblemAlgorithm','cg',...
        'HessMult',@HessMultFcn,...
        'DerivativeCheck','off'); 
       % 3000: the default value of 'MaxFunEvals' for interior-point method
       % 'DerivativeCheck': whether to check the user-provided derivatives
    %if verbose<=1
        options = optimset(options,'Display','off');
    %end
    
    % solve    
    x = fmincon(@fun,x0,A,b,Aeq,beq,lb,ub,nonlcon,options);

    % outputs:        
    w = sqrt(max(0,x(l+1:l+m))); 
    if nargout>1
        sol.beta = x(1:l);    
        sol.b = 0; %  SVM in the primal: f(x) = \sum_{i} \alpha_i k(x_i, x);
        varargout{1} = sol;
    end
end