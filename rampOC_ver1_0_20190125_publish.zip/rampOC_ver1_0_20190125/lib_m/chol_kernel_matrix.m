function [L r]= chol_kernel_matrix(X,arg)
% low rank approximation of a kernel matrix by cholesky factorization
% Inputs:
%   X: matrix of n-by-m, each row consists a sample, i.e.
%          X consists of n samples and m features;
%   arg: a structure containing the items:
%     .kernelType: a string indicating kernel type, e.g.: 'rbf': RBF
%         (Gaussian)  kernel
%     .r1: a positive scalar indicating the kernel arguments
%     .tol: a positive scalar indicating the tolerance to calculate 
%           the Cholesky factorization of the kernel matrix, the
%           factorization terminate when the diagnal elements of G
%           decreases to the given tolerance;
%     .w: Optional, a vector of feature weights, with length m (number of
%        features; default []: all features are set weight 1.0;
% Outputs:
%   L: a n-by-r matrix with r<=n; L is a lower triangular matrix: 
%           L(i,j)=0, if i>j
%           K = L * L';
%       where K(i,j) = k(x_i,x_j), k() is the given kernel function;
%   r: the rank (column number) of L;

[kernelType, r1, tol,w] = getArgument(arg,{'kernelType','r1','tol','w'});
[n m] = size(X); % n: the number of samples, m: the number of features
if isempty(w) || length(w)~=m
    X = X';
else
    X = sparse(1:m,1:m,w)*X';
end

    function v = K_f(arg1,arg2)
        % arg1, arg2: the row and column indices 
        % if there is only 1 argument, return the diagnoal elements of the 
        %       kernel matrix;
        if nargin==1
            v = ones(n,1); 
                % the diagnal elements of the kernel matrix
                %   Note that: for the Gaussian (RBF) kernel, the diagnal 
                %   elements of the kernel matrix are 1, for other kernels 
                %   it is NOT necessarily the value 1. Thus, this line of 
                %   code needs to be improved;
        else
            v = kernelMatrix_OnceaLine(kernelType,X(:,arg1),X(:,arg2),r1,[]);
               % X has transformed with the feature weights, so the last 
               %   argument is set [];
        end        
    end

[L r piv] = ichol_col(@K_f,tol);

% adjust rows of L: P*K*P' = L*L' ==> K = (P'*L) * (P'*L)' 
ind_v = (1:n)';
id_v = (piv ~= ind_v);
L(piv(id_v),:) = L(ind_v(id_v),:);

end

