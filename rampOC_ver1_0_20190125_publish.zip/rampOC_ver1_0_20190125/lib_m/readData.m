function [data text] = readData(fileName,arg)
% read PSM data
% Inputs:
%   fileName: txt or Excel file name (including the path) 
%   arg: a structure indicating the arguments
%     .getDataType: Optional, indicating to read numerical data or text data   
%         'total': read both numerical and text data, default value;
%         'numeric': merely read numeric data, then TEXT returns []; 
%         'string': merely read data of string, then DATA.input is set [];
%     .verbose: an integer number, indicating the degree to put out
%         progression information; see problemArg() for detail;
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%            implement the function .getOnecolumn in future version 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     .getOneColumn: Optional, default ''; a string indicating the feature
%        that the function will read from the data file;
%        (1) if this argument is set, the function MERELY return DATA as
%            the values of this one given feature; and  text is set [];
%        (2) if the feature values are string, DATA is a (column) string
%            cell array; if the feature values are numerical, DATA returns
%            as a column vector; 
%        (3) the  type (numerical or string) of the feature is identified
%            by FEATURE_ORIGIN_NUMERIC and FEATURE_ORIGIN_STRING in
%            problemArg.m. 
%            a. if the feature contains in FEATURE_ORIGIN_NUMERIC, it is
%               numeric; 
%            b. if the feature contains in FEATURE_ORIGIN_STRING, it is 
%               read as string type;
%            c. otherwise, the user should assign the value type of the
%               feature as follows:
%                  'featureName_numeric' or 'featureName_string',
%               where featureName is feature name contained in the title
%               row of the data file. E.g., if the user merely want to read
%               one feature, deltaM, as numeric values then this argument
%               can be set 'deltaM_numeric';
%             d. if the user is not sure whether the insteresting feature
%               contained in FEATURE_ORIGIN_NUMERIC or
%               FEATURE_ORIGIN_STRING, just use the format described in c.
%%%%%%%%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     .fileType: Optional, 'txt' or 'xls', 'xlsx', indicating the  type
%       of the data file, default '': 
%        'txt': indicating the datafile is text file, it is independent with
%           the  ext name of the file ( Eg, can be csv, txt, or other
%           files);
%        'xls', 'xlsx': Excel file;
%        '': identify the data file type by its suffix;
%     .delimiter: Optional, the delimiter of the values of different fields 
%           of text data file,  effective if the file is text type;
%     .decoyPrefix: Optional, a string indicating the leading prefix of the
%        protein fields of a decoy PSM,  default 'Reverse';  i.e., if PSM
%        with the protein field begining with the given prefix, then it is
%        labeled as a decoy PSM (label -1),  otherwise it is labeled as a
%        target PSM (label 1);  
%        This parameter is effective if no label feature exists in the data
%        file. 
%     .sheet: Optional, Excel sheet name, effective if the file is Excel file;
%           default 'sheet1';
%     .titleRow: Optional, a positive integer, indexing the title row, 
%       e.g. titleRow = 3: then the 3rd row is title row, and the first two
%       rows will be ignored; default 1;
%        Note that 
%        a. the title row contain the names of features of the data file; 
%           The title row is necessary and important. The function identify
%           different feature columns by feature names of the title row.  
%        b. the order of the features (columns) of data is free; but the
%           spelling  of the necessary feature names should exactly
%           coincide with that  set beforehand (by FEATURE_ORIGIN_NUMERIC
%           and FEATURE_ORIGIN_STRING in problemArg.m );
%        c. if a feature is not wanted to read, add a minus mark '-' at
%           the beginning of the feature name, e.g. '-deltaM' notifies the
%           function neglects the corresponding values of the deltaM column
%           in the data file;  
%        d. if a string feature is wanted to read and is not a Basic String
%           Feature, add a plus mark '+' at the beginning of the feture
%           name, e.g., '+deltaN';
%        d. all the features except the basic string features and the ones
%           marked by '+' should be numeric values;  
%        e. the following features (if exist) are dealt with specially
%           * label: if the label feature exist in the data file, then the
%             type of the PSM records are determined by the feature values; 
%             This feature values should consist of 1 and -1, indicating
%             the type of  PSM records with 1: target PSM, -1: decoy PSM;
%           * protein: If the label feature does not exist, then the labels
%             of the PSM records are determined by the protein feature.
%             The label is set to -1 (decoy) if with the protein string
%             begins with the specified decoyPrefix (set in problemArg.m); 
%             otherwise the label is set to 1 (target PSM).
%           * ions: supports the ions feature values with the form like
%             "4/8", "2011/10/20", "2011-10-20".  
%         f. for Excel files, it's not need to specify arg.titleRow, the 
%           function will identify and remove the leading blank rows (users
%           should clear the redundant rows as blank for Excel data files); 
%
%         a typical data file may be written as follows:
%
%   spectrum           peptide	  protein	      xcorr  -desp <-- title row
%   B_GCN5_flow.0901.1 F.AGVGA.M Reverse_YAL009W 1.108   atLab          <-- values of PSM 1
%   B_GCN5_flow.0901.2 F.BGGA.M  YAL009W         2.008   atLab          <-- values of PSM 2
%   ...
%  
%     where each row consists a record  of a PSM, '-desp' notifies that
%     the corresponding feature 'desp' should be neglected.
% Outputs:
%  data: a structure containing the following fields
%    .input: a matrix with columns of the numerical features;
%    .input_feature: a string cell array (row array), with the i-th element  the
%      feature name of the i-th column of the matrix DATA.INPUT;  
%    .output: a column vector consisting of the label of PSMs, 1: target,
%         -1: decoy; 
%  text: a structure containing the text data, each field contains  a
%    column string cell array;


% arguments
% % % feature_name_protein = problemArg('feature_name_protein');
% % %         % name of the protein feature
% % % feature_name_ions = problemArg('feature_name_ions');  
% % %         % name of the ions feature
% % % feature_name_label = problemArg('feature_name_label');  
% % %         % name of the label feature

[feature_name_protein,feature_name_ions,feature_name_label,feature_origin_string]...
    = problemArg('feature_name_protein','feature_name_ions','feature_name_label',...
        'feature_origin_string');  
               
% complete the argument values with default value 
argument_cell =    {'getDataType','getOneColumn','fileType','delimiter',...
        'decoyPrefix','sheet','titleRow','verbose'};
% % % argument_default_val = cellfun(@problemArg,argument_cell,'UniformOutput',false);
% % % arg = completeArg(arg,argument_cell,argument_default_val);
arg_c = cell(8,1);
[arg_c{1},arg_c{2},arg_c{3},arg_c{4},arg_c{5},arg_c{6},arg_c{7},arg_c{8}]=...    
    problemArg('getDataType','getOneColumn','fileType','delimiter',...
        'decoyPrefix','sheet','titleRow','verbose');
arg = completeArg(arg,argument_cell,arg_c);

% initialize the outputs
data = struct('input',[],'input_feature',[],'output',[]);
text = struct();

% identify file type
% flag_fileType = 0; % 1: txt file, 2: xls file, 0: files of other type
if ~isempty(arg.fileType)
    switch lower(arg.fileType)
        case {'txt'}
            flag_fileType = 1;
        case {'xls','xlsx'}
            flag_fileType = 2;
        otherwise
            error('Unexpected file type is set. Only text or Excel file is supported.');
    end    
else
    [pathstr, fname, ext] = fileparts(fileName);
    switch lower(ext)
        case {'.txt','.csv'}
            flag_fileType = 1;
        case {'.xls','.xlsx'}
            flag_fileType = 2;
        otherwise
            warning('The data file is dealed with as text file.');
            flag_fileType = 1;
    end    
end

% identify data type to read
if ~isempty(arg.getDataType)
    switch lower(arg.getDataType)
        case {'numeric'}
            flag_getDataType = 1; % merely read numeric data
        case {'string'}
            flag_getDataType = 2; % merely read text data
        otherwise
            flag_getDataType = 3;
    end
else
    flag_getDataType = 3;
end

% the arg.getOneColumn argumnet
if ~isempty(arg.getOneColumn)
    flag_getOneColumn = 1; 
else
    flag_getOneColumn = 0;
end

% read the title line from txt file
if flag_fileType==1
    fid = fopen(fileName,'r');    
    header_cell = textscan(fid,'%[^\r\n]',1,'HeaderLines',arg.titleRow-1);
    title_cell = textscan(header_cell{1}{1},'%s','Delimiter',arg.delimiter,...
        'MultipleDelimsAsOne',1);     % seperate  str to items
    title_cell = title_cell{1};      
end

% read the title line and raw data from xls file
titleRow_xls = 1; % title row for raw data read from Excel files,
        % note that xlsread() idetify and remove the starting blank rows
        % automatically 
if flag_fileType==2
    if verLessThan('matlab', '7.10') % matlab2010
        [num,txt,raw] = xlsread(fileName,arg.sheet);
        clear('num','txt');
    else
        eval('[~, ~, raw] = xlsread(fileName,arg.sheet);');
    end
    title_cell = raw(titleRow_xls,:);  % get the title row    
end

% put out of the feature names consisting of the title row
if arg.verbose>=2
    fprintf(1,'Title row of the data file has been read.\n');
    fprintf(1,'There are %d feature names consists in the title line: ',length(title_cell));
end
if arg.verbose>=3
    fwritef(1,'',title_cell,'');
elseif arg.verbose==2
    if length(title_cell)==1
        fprintf(1,'%s.\n',title_cell{1});
    elseif length(title_cell)==2
        fprintf(1,'%s, \t%s.\n',title_cell{1},title_cell{2});
    elseif length(title_cell)==3
        fprintf(1,'%s, \t%s, \t%s.\n',title_cell{1},title_cell{2},title_cell{3});
    else % length(title_cell)>=4
        fprintf(1,'%s, \t%s,..., \t%s.\n',title_cell{1},title_cell{2},title_cell{end});
    end
end


% identify the features (columns)

% % % feature_origin_string = problemArg('feature_origin_string');

title_cell = cellfun(@lower,title_cell,'UniformOutput',false);
% converting the feature names to lower case
title_cell = cellfun(@strtrim,title_cell,'UniformOutput',false);
% trim the leading and trailing white space

% * try to read the 1st PSM record, to check the validadity of the data file
if flag_fileType==1
    firstPSM_cell = textscan(fid,'%[^\r\n]',1,'HeaderLines',arg.titleRow);
    element_cell = textscan(firstPSM_cell{1}{1},'%s','Delimiter',arg.delimiter,...
        'MultipleDelimsAsOne',1);
    element_cell = element_cell{1};
else % flag_fileType==2
    element_cell =raw(2,:); % the 1st row of raw is the title row for Excel file
end

if arg.verbose>=3
    fwritef(1,'The 1st record:',element_cell,'');
end
%* check each value of the elements of the 1st record
%    and determine the type of each feature
if length(element_cell)~=length(title_cell)
    warning('The title row has %d fields, but the 1st PSM record has %d fields.',...
        length(title_cell),length(element_cell));
end
feature_string = feature_origin_string;	 % contain features of string values
for ii=1:length(element_cell)
    feature_s = title_cell{ii};
    if feature_s(1) == '+'
        feature_string(end+1) = title_cell(ii); % record the feature in feature_string
    elseif feature_s(1)~='-' && ~isnumber(element_cell{ii}) && ~ismember(feature_s,feature_origin_string)
        if ~strcmpi(feature_name_ions,feature_s) && arg.verbose>=3
            warning('The %s feature value ''%s'' is not numeric, it is dealt with as string.\n',...
                title_cell{ii},element_cell{ii});
        end
        feature_string(end+1) = title_cell(ii);
    end
end
    % add ions  as string-valued feature
if ~ismember(feature_name_ions,feature_string)
    feature_string{end+1} = feature_name_ions;
end

%* elements of the vector ind_t_f(ii): 
%     3: ii-th column of the data file is the label feature
%     2: ii-th column of the data file is a numeric feature (do not include the label feature);
%     1: ii-th column of the data file is a string feature (include the ions feature); 
%     0: ii-th column of the data file is a feature to be neglected
len_feature = min(length(title_cell),length(element_cell));
ind_t_f = zeros(len_feature,1);
[imb_v] = ismember(title_cell,feature_string);
for ii=1:len_feature
    feature_s = title_cell{ii};
    if  imb_v(ii)        
        ind_t_f(ii) = 1;
    elseif feature_s(1)=='-'
        inf_t_f(ii) = 0;
    else        
        ind_t_f(ii) = 2;        
    end
end
   % identify the label feature
[flag_exist_label id_label_title] = ismember(feature_name_label,title_cell(1:len_feature));
if flag_exist_label
    ind_t_f(id_label_title) = 3;
end
 
   % identify the ions feature
[flag_exist_ions id_ions_title]= ismember(feature_name_ions,title_cell(1:len_feature)); 
            % flag_exist_ions: whether 'ions' exist
numeric_feature_ind = ind_t_f==2;
if flag_exist_ions
    numeric_feature_ind(id_ions_title) = 1;
end
data.input_feature = title_cell(find(numeric_feature_ind)); 
    % numeric feature names 
    % length(numeric_feature_ind) = len_feature <= length(title_cell)
[temp id_ions_input] = ismember(feature_name_ions,data.input_feature);

% read the raw data from txt file
if flag_fileType==1   
    % * construct format string
    format_str = '';
    for ii=1:len_feature        
        if  ind_t_f(ii) == 1
            format_str = [format_str '%s'];                        
        elseif ind_t_f(ii) ==2 || ind_t_f(ii) ==3 
            format_str = [format_str '%f'];                     
        else %ind_t_f(ii) ==0
            format_str = [format_str '%*s']; % neglect the feature   
        end
    end 
    format_str = [format_str '%*[^\r\n]']; % neglect the remaining features
      % read data      
    frewind(fid);   
    raw = cell(1,len_feature);
    raw(ind_t_f>0) = textscan(fid,format_str,'HeaderLines',arg.titleRow,...
         'delimiter',arg.delimiter,'MultipleDelimsAsOne',1,'ReturnOnError',0);
end

% Assign the text data    
if flag_fileType==2 % xls file
    m = size(raw,1); % row number of raw
    p = titleRow_xls + 1;           
end
    % num_sample: number of samples
if flag_fileType==2 % xls file
    num_sample = size(raw,1) - titleRow_xls; 
else % text file
    ind0 = find(ind_t_f>0,1,'first');
    if ind0>0
        num_sample = length(raw{ind0});
    else
        num_sample = 0;
    end
end
if flag_getDataType ~=1        
    for ii=1:len_feature
        if ind_t_f(ii)==1 && ii~=id_ions_title % exclude the ions feature
            if flag_fileType==2 % from xls file
                text.(title_cell{ii}) = raw(p:m,ii);
            elseif flag_fileType==1 % from txt file
                text.(title_cell{ii}) = raw{ii};
            end        
        end
    end
end

% Assign the numeric data  
data.input = [];
if flag_getDataType~=2  && ~isempty(data.input_feature)
      % ininialize data.input
    n_numeric = length(data.input_feature);    
    data.input = zeros(num_sample,n_numeric);        
    if flag_fileType==2 % xls file
        %  deal with ions feature
        if  flag_exist_ions 
            data.input(:,id_ions_input) = transformIons(raw(p:m, id_ions_title));    
        end        
        data.input(:,(1:n_numeric)~=id_ions_input) = cell2mat(raw(p:m,ind_t_f==2));        
    else % txt file
         %  deal with ions feature     
        if  flag_exist_ions 
            data.input(:,id_ions_input) = transformIons(raw{id_ions_title});    
        end        
        data.input(:,(1:n_numeric)~=id_ions_input) = cell2mat(raw(ind_t_f==2));        
    end        
end

% get or produce the labels of the PSM samples
%   1: target PSM;  -1: decoy PSM
data.output = [];
if flag_exist_label
    if flag_fileType == 2 % xls file        
        data.output = cell2mat(raw(p:m,id_label_title));
    else
        data.output = cell2mat(raw{id_label_title});
    end
end
[flag_exist_protein ind_pro_t] = ismember(feature_name_protein,title_cell);
  % flag_exist_protein: whether the name of protein contained in title row 
if ~flag_exist_label && flag_exist_protein
    strPrefix = arg.decoyPrefix;
    n_prefix = length(strPrefix);    
    if flag_fileType == 2 % xls  file
        label_v = cellfun(@(x) ~strncmpi(strPrefix,x,n_prefix), ...
            raw(p:m,ind_pro_t),'UniformOutput',true);
    elseif flag_fileType == 1 % txt file
        label_v = cellfun(@(x) ~strncmpi(strPrefix,x,n_prefix), ...
            raw{ind_pro_t},'UniformOutput',true);
    end    
    data.output = ones(num_sample,1);    
    data.output(~label_v) = -1;
end

% close txt file
if flag_fileType==1
    fclose(fid);
end

end