function printProgress(state,totalStep,fid)
% print the progress string 
% Inputs:
%  state: 
%     0, put out the initialized string;
%         then the following argument totalStep,  is not  needed;
%     other positive integer, put out the progress string for STATE steps
%  totalStep: a positive integer indicating the total number of steps 
%  fid: Optional, a file ID, default 1 (the command window)

persistent step_current num_block_pre
    % num_block_pre: number of block that has printed
if isempty(step_current) 
    step_current = 0;
    num_block_pre = 0; 
end

if nargin<4 || isempty(fid)
    fid = 1;
end

char_undo = '='; % character representing the progress undone, each 
                 %  character is viewed as a block 

char_done = '>'; % character representing the finished progress 

num_block_total = 20; % total number of blocks

str_init = ones(1,num_block_total)*char_undo;
if state ==0
    %fprintf(fid,'\n%s','           tasks: ');
    fprintf(fid,'\n\t\t');
    fprintf(fid,'%c',str_init);
    %fprintf(fid,'\n%s','current progress: ');
    fprintf(fid,'\n\t\t');
else % state >0
    step_current = step_current + state;
        % current block
    num_block_current = floor(num_block_total * step_current/totalStep);
    
    num_block_offset = num_block_current - num_block_pre;
    % print char_done
    if num_block_offset>0
        for ii =1:num_block_offset
            fprintf(fid,char_done);
        end
    end
    num_block_pre = num_block_current;
    % print the newline character
    if num_block_current >= num_block_total &&  step_current >= totalStep
        fprintf(fid,'\n');        
        step_current = [];
        num_block_pre = []; 
    end
        
end

    

end


