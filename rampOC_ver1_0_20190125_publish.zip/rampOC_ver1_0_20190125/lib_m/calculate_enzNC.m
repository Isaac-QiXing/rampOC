function [enz] = calculate_enzNC(peptide_cell)
% identify whether  N terminus and C terminus of the peptide are tryptic
% Input:
%  peptide_cell: peptide cell array, e.g. {'A.KAGR.I','K.KGAPGP.N'};
% Output:
%  enz: a n-by-2 matrix, n is the length of peptide_cell
%   enz(:,1): 
%       each element 0 or 1: whether the peptide have a tryptic
%       N-terminus (the left side of the peptide string);
%   enz(:,2): 
%       each element 0 or 1: whether the peptide have a tryptic
%       C-terminus 
  
enz=cell2mat(columnVec(cellfun(@enzNC,peptide_cell,'UniformOutput',false)));

end