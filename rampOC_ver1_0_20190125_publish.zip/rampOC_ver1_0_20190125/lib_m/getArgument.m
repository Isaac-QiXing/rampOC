function varargout=getArgument(nv,argName_cell)
% get the the variables from name-value pair cell array
% Inputs:
%   nv: a cell array or a struct,
%    1) if nv is a cell array: it consists paris of name-value
%    for instance {'index_v', [1.1 1.2 1.3],'indexName','coherence'}
%    2) if nv is a struct, it has the following structure
%       nv.field1,
%       nv.field2, ...
%       nv.fieldn;
%   argName_cell: Optional, a cell array consisting names of the arguments
%     to obtain; by default, assign all the existing variable to variables with the
%     same names in the caller function;
%  Outputs:
%    if no outputs (nargout==0), the function produces varables for the
%    caller with the variable name indicated in  argName_cell; 
%    Otherwise,
%    varargout{i} is assigned to the i-th variable indicated by argName_cell;
%      if the variable in argName_cell does not exist, set the variable as [];


% e.g.
%  if in a function test.m called:
%     getArgument({'id',34, 'sex', 'male'}, {'id','sex','height'});
%  then in the workspace of test.m function, there exists the following
%   variables: id, sex, and height, with values 34, 'male', and [], resp.
%   variables which name not contained in nv will be assigned [];

if iscell(nv)    
    if exist('argName_cell','var')
        len_name_val = length(nv);
        name_cell_setted = nv(1:2:len_name_val);
        for ii = 1:length(argName_cell)
            name_Var = argName_cell{ii}; 
            i_pair = find_cellstr(name_cell_setted,name_Var);
            if i_pair && 2*i_pair<=len_name_val
                temp_var = nv{2*i_pair};
            else
                temp_var =[];
            end
            if nargout==0
            	assignin('caller', name_Var, temp_var); % assign in the workspace of the caller
            elseif ii<=nargout 
                varargout{ii} = temp_var; % assign to the output variable of the function
            end
        end
    else
        for ii=1:floor(length(nv)/2)     
            if nargout==0
                assignin('caller',nv{2*ii-1},nv{2*ii});
            elseif ii<=nargout
                varargout{ii} = temp_var;
            end
        end
    end
elseif isstruct(nv)
    if  exist('argName_cell','var')  
        for ii = 1:length(argName_cell)
            fieldName = argName_cell{ii}; 
            if ~isfield(nv,fieldName) || isempty(nv.(fieldName))
                temp_var = [];
            else
                temp_var =  nv.(fieldName); 
            end
            if nargout==0
                assignin('caller', fieldName, temp_var); 
                        % assign in the workspace of the caller
            elseif ii<=nargout 
                varargout{ii} = temp_var; % assign to the output variable of the function
            end
        end 
    else
        field_cell = fieldnames(nv);
        for ii = 1:length(field_cell)
            if nargout==0
                assignin('caller', field_cell{ii}, nv.(field_cell{ii})); 
            elseif ii<=nargout
                varargout{ii} = nv.(field_cell{ii});
            end
        end 
    end
end

end

function id = find_cellstr(strcell,str)
% find the first location where str occurs in the cell array strcell (case
% insensitive), return 0 if no occurrance
    is_identical_v = cellfun(@(x_str)strcmpi(x_str,str),strcell);
    id = find(is_identical_v);
    if isempty(id)
        id = 0;
    end
end

