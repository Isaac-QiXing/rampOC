function [L r piv] = ichol_col(Q,tol)
% column-wise Cholesky Factorization with symmetric pivoting
%               PQP' = L*L'
% Inputs:
%  Q: 1) a positive semi-definite symetric matrix 
%    or
%     2) a function which can generate 
%       * the i-th column of the potential given matrix (to be factorized),
%         for any i; 
%       * the diagonal elements of the potential given matrix.
%       if Q is a function, it has the following interface:
%           * diag_v = Q('diag')
%               return a column vector consisting of diagnal elements;
%           * v = Q(ind_r,ind_c)
%               with either ind_r or ind_c a scalar indicating the row or 
%               column, the other argument is a vector of indices;
%             e.g. v = Q(3,[1 5 2 3]) returns the vector of Q(3,[1 5 6 2
%             3]);
%             
%  tol: Optional, a positive scalar indicating the tolence of the minimum
%    diagonal elements of the triangular matrix L to be calculated;
% Outputs:
%  piv: a column vector indicating the permutation matrix P:
%                 P(k,piv(k)) = 1   for k=1,...,n
%       piv(j) indicating that the current j-th column (row) corresponds
%       to the original piv(j)-th column (row) of the matrix Q;
%  L: a triangluar matrix (with the remaining elements 0), L has r columns
%                   PQP' = L*L'
%     where P is the permutation matrix;
%  r: rank of matrix L

% references:
%  [1] S. Fine, K. Scheinberg, Efficient SVM traing using low-rnak kernel
%    representations. Journal of Machine Learning Research
%    2(2001):243--264.
%  [2] C. Lucas, Lapack-style codes for level 2 and 3 pivoted Cholesky
%    factorization. Numerical Analysis Report No. 442. 2004.


if nargin<2 || isempty(tol)
    tol = 1.0E-6; % default value of tol
end


if isnumeric(Q) % Q is a matrix
    diagL = diag(Q);
else
    diagL = Q('diag');
end
n = length(diagL); 

block_col = min(500,n); % the number of columns to append onto matrix L at each time 
dots = zeros(n,1); % dots is a column vector
piv = (1:n)';
L = zeros(n,block_col);
num_col_L = block_col; % current column number of L
temp_v = zeros(1,n); % a row vector
r=0;
for j=1:n
    if j>1
        dots(j:n) = dots(j:n) + L(j:n,j-1).^2;
    end
    [eta q] =max(diagL(piv(j:n))-dots(j:n)); 
        % note that here should be "diagL(piv(j:n))", not "diagL(j:n)"
    q = q+j-1;
    if eta<=tol
        r=j-1; % the rank of L is j-1
        break;
    end
    % assign the j-th column of L
    if num_col_L<j
        L = [L zeros(n,block_col)]; % enlarge the size of L
        num_col_L = num_col_L + block_col;
    end
    L(j:n,j) = Q(piv(j:n),piv(q)); 
    % swap L(j,1:j)  and L(q,1:j)
    temp_v(1:j) = L(j,1:j);
    L(j,1:j) = L(q,1:j);
    L(q,1:j) = temp_v(1:j);
    % swap dots(j) and dots(q)
    temp = dots(j);
    dots(j) = dots(q);
    dots(q) = temp;
    % swap piv(j) and piv(q)
    temp = piv(j);
    piv(j) = piv(q);
    piv(q) = temp;
    % calculate L(j,j)    
    L(j,j) = sqrt(L(j,j)-dots(j));    
    % update j-th column
    if 1<j && j<n
        L(j+1:n,j) = L(j+1:n,j) - L(j+1:n,1:j-1)*L(j,1:j-1)';
    end
    if j<n
        L(j+1:n,j) = L(j+1:n,j)/L(j,j);
    end
end

% assign r
if r==0
    r=n;
end
% trim the zeros columns of L
if r<num_col_L
    L(:,r+1:num_col_L) = [];
end


end