function acc = cal_accuracy(num_s)
% calculate the FDR, TPR, FPR 
% 
% Inputs:
%   num_s: array of accuracy structure contains at least the following fields  
%   .TP : number of true positives 
%   .FP : number of false positives
%   .FN : number of false negative
%   .TN : number of true negative
% Outputs:      
%  acc: array of accuracy structure with the same length as num_s
%   .FDR: false discovery rate: 2*FP/(FP+TP) 
%   .TPR: true positive rate:  TP/(TP+FN)
%   .FPR: false positive rate: FP/(FP+TN)

len_num = length(num_s);

acc = struct('FDR',cell(len_num,1),'TPR',[],'FPR',[]);

for ii=length(num_s)
    acc(ii).FDR = 2* num_s(ii).FP/(num_s(ii).TP + num_s(ii).FP);
    acc(ii).TPR =  num_s(ii).TP/(num_s(ii).TP + num_s(ii).FN);
    acc(ii).FPR =  num_s(ii).FP/(num_s(ii).TN + num_s(ii).FP);
end

