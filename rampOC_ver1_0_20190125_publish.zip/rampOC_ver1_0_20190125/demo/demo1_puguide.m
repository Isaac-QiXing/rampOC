% demo1. use FoApL for PU classification with the classical binary
% classification instances    

clear

pathstr = '../';
dataset = 'breast-cancer';

input.dataFile  = [pathstr dataset];
input.testFile  = []; % users may also specify the test file 

output.matDataFile =    sprintf('%s%s.mat',pathstr,dataset);
output.matTrainFile =   sprintf('%s%s_train.mat',pathstr,dataset);
output.matTestFile =    sprintf('%s%s_test.mat',pathstr,dataset);
matTrainFile_pu =       sprintf('%s%s_putrain.mat',pathstr,dataset);
matScoreFile =          sprintf('%s%s_score.mat',pathstr,dataset);

foapl_read(input,output); 
    % read libsvm training data and test  data of binary classification, 
    %   if input.testFile =[], split the instance of dataFile to train set and test set

foapl_pu_training_file(output.matTrainFile,  matTrainFile_pu,   0.5);
% make pu training file
%  the 3rd input: classPrior, a constant sclar in (0,1) in dicating the ratio of the
%      positive distribution among the missing labels
 
foapl_solve(matTrainFile_pu, output.matTestFile, matScoreFile);
% train a PU classifier, calculate scores of training instances and test instances          

% usage 2. set kernel parameters
%      foapl_solve('-lambda','0.125','-r','1', matTrainFile_pu, output.matTestFile, matScoreFile);
          
acc= foapl_accuracy(matScoreFile,output.matTestFile);    % test accuracy
