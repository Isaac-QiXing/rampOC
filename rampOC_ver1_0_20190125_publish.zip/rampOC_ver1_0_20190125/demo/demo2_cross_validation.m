% demo2_cross_validation

pathstr = '../';
dataset = 'breast-cancer';

input.dataFile  = [pathstr dataset];
input.testFile  = []; % users may also specify the test file 

output.matDataFile =    sprintf('%s%s.mat',pathstr,dataset);
output.matTrainFile =   sprintf('%s%s_train.mat',pathstr,dataset);
output.matTestFile =    sprintf('%s%s_test.mat',pathstr,dataset);
matTrainFile_pu =       sprintf('%s%s_putrain.mat',pathstr,dataset);
% % matScoreFile =          sprintf('%s%s_score.mat',pathstr,dataset);

foapl_read(input,output); 
    % read libsvm training data and test  data of binary classification, 
    %   if input.testFile =[], split the instance of dataFile to train set and test set

foapl_pu_training_file(output.matTrainFile,  matTrainFile_pu,   0.5);
% make pu training file
%  the 3rd input: classPrior, a constant sclar in (0,1) in dicating the ratio of the
%      positive distribution among the missing labels
 
  
% usage 1.
    foapl_cv(matTrainFile_pu);
%
% usage 2.
%     par_search = struct( 'lambda',[   2^(-3) 2^(-6) 2^(-9)  ],...
%         'r1',[2^(-2) 1  2^1   2^3    2^6     2^15]);
%     foapl_cv(matTrainFile_pu,par_search);

% usage 3.
%    
%    foapl_cv(matTrainFile_pu,par_search,@findBestResult);

% usage 4. specify parameters for cross validation
%    foapl_cv('-k','4','-z','3000',matTrainFile_pu,par_search,@findBestResult);
  
  