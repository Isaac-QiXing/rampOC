function i_opt = findBestResult(result_st,varargin)
%  find a group of best result
%  Inputs:
%    result_st: a struct array of the result output by   pu_predict()
%    varargin{1},  mode_str,
%    an optional input variable, refer the first optional input variable of
%           pu_label()
%  Outputs:
%  	 i_opt: an index of the best result
%
% Version:
%   2019.1.4   improve the method to find a good result on mode 'p' and 'pu'
%   2018.12.29 add an optional input variable, mode_str

if nargin>=2
    mode_str = varargin{1};
    mode_str = strtrim(lower(mode_str));
else
    mode_str = 'normal';
end

i_opt = [];
[n,m] = size(result_st);
temp_c = cell(n,m);
%threshold_tpr_tnr = 0.01; % minimum threshold of TPR and TNR

threshold_min_TN = 0.3; % threshold of  TN 
threshold_min_FN = 0.3; 
threshold_min_TP = 0.3;
threshold_min_FP = 0.3;
k_top = 3; % value of k, that top-k TPs (or TNs) will be checked


% threshold of minimum FN  
%    (note that TP+FN is roughly a constant, then FN==0 indicates that all the positives are
%    predicted correct, overfitting often occurs) 

% calculate the mean TP, FP, TN, FN
[temp_c{:,:}] = deal(result_st(:,:).TP);
tp_m  = cell2mat(temp_c);
tp_v = mean(tp_m,2);
tp_min_v = min(tp_m,[],2);

[temp_c{:,:}] = deal(result_st(:,:).FP);
fp_m  = cell2mat(temp_c);
fp_v = mean(fp_m,2);
fp_min_v = min(fp_m,[],2);

[temp_c{:,:}] = deal(result_st(:,:).TN);
tn_m  = cell2mat(temp_c);
tn_v = mean(tn_m,2);
tn_min_v = min(tn_m,[],2);

[temp_c{:,:}] = deal(result_st(:,:).FN);
fn_m  = cell2mat(temp_c);
fn_v = mean(fn_m,2);
fn_min_v = min(fn_m,[],2);

% TNR= TN/(TN+FP)
% FNR=FN/(FN+TP)
% FPR=FP/(FP+TN)
% TPR=TP/(TP+FN)
tpr_v = tp_v./max(tp_v+fn_v,1);
tnr_v = tn_v./max(tn_v+fp_v,1);
% accuracy_v = (tp_v+tn_v)./(tp_v+tn_v+fp_v+fn_v);
ave_tpr_tnr_v = 0.5*(tpr_v + tnr_v); % mean value of TPR and TNR

len = length(tpr_v);
ind = 1:len;



%ind2 = find(tpr_v >=threshold_tpr_tnr & tnr_v>=threshold_tpr_tnr);
switch mode_str
    case {'pu','p','p_reverse'}
        %ind2 = find(tn_min_v >=threshold_min_TN & fn_min_v>=threshold_min_FN);
        ind2 = find(tn_v >=threshold_min_TN & fn_v>=threshold_min_FN);
    case {'n','n_reverse'}         
        %ind2 = find(tp_min_v >=threshold_min_TP & fp_min_v>=threshold_min_FP);     
        ind2 = find(tp_v >=threshold_min_TP & fp_v>=threshold_min_FP);
    otherwise %{ 'pn', 'pn_reverse','normal'}
        %ind2 = find(fp_min_v >=threshold_min_FP & fn_min_v>=threshold_min_FN); 
        ind2 = find(fp_v >=threshold_min_FP & fn_v>=threshold_min_FN); 
end



if isempty(ind2)
    %i_opt = -1; % no qualified results
    fprintf(1,'k-fold cross validation: no qualified results found.\n');
else % ind2 is not empty
    ind = ind2;
end

%%%
%  fwritef(1,'tp_v',tp_v,'','fp_v',fp_v,'','tn_v',tn_v,'','fn_v',fn_v,'','ind2',ind2,'');
%%%

k_top = min(k_top,length(ind));


switch mode_str
    case {'pu','p','p_reverse'}
        
        %%%[~,i_max] = max(tpr_v(ind));
         [~,i_ind] = sort(tpr_v(ind),'descend');
         i_top_tp = ind(i_ind(1:k_top)); % indices of top-k TPs
         [~,ii_tp]= max(tnr_v(i_top_tp));
         i_opt = i_top_tp(ii_tp);
        
    case {'n','n_reverse'} 
% % %         [~,i_max] = max(tnr_v(ind));
% % %         i_opt = ind(i_max);
         [~,i_ind] = sort(tnr_v(ind),'descend');
         i_top = ind(i_ind(1:k_top)); % indices of top-k TNs
         [~,ii_tp]= max(tpr_v(i_top));
         i_opt = i_top(ii_tp);
% % %     %case { 'pn', 'pn_reverse'}         
    otherwise %{ 'pn', 'pn_reverse','normal'}
        %[~,i_max] = max(accuracy_v(ind));
        [~,i_max] = max(ave_tpr_tnr_v(ind));
        i_opt = ind(i_max);
end







% % % ind = find(tpr_v >=threshold_tpr_tnr & tnr_v>=threshold_tpr_tnr);
% % % if isempty(ind)
% % %     %i_opt = -1; % no qualified results
% % %     fprintf(1,'k-fold cross validation: no qualified results found.\n');
% % %      [~,i_opt] = max(accuracy_v);
% % % else
% % %     [~,i_max] = max(accuracy_v(ind));
% % %     i_opt = ind(i_max);
% % % end

end