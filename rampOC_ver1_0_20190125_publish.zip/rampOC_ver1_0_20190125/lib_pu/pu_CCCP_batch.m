function [sol,fval, exitFlag] = pu_CCCP_batch(arg,X_col,y_total)
%   solve PU learning model with ramp loss  by batch CCCP (Convex-Concave Procedure);
%
% Inputs:
%     arg:
%        arg.cp: a positive number,  the penalty paramter of the empirical
%           loss induced by the positive samples;
%        arg.cu: a positive number,  the penalty paramter of the empirical
%           loss induced by the negative samples;
%%%        arg.lambda:   the weight parameter of theta;
%        arg.w: a vector indicating the weight of each feature for
%           calculating the kernel matrix
% % %        arg.mode:  1 or 'Fix': Fix the value of lambda
% % %                   0 or 'SPL': update the parameter lambda with Self-paced
% % %                      learning terminated with the specified value;
%
%   X_col:   the matrix of samples,  each column indicating a sample
%        the number of rows of X_col equal to the length of arg.w;
%
%   y_total: a column vector of labels consisting of 1 and -1; with length equal to
%       the column number of X_col
% Outputs:
%   sol: the solution;
%      sol.alpha: a column vector, indicating the solutions;
%           .b: a scalar;
%           the discriminat function is determined by
%                 f(x) = \sum_{i} \alpha_i k(x_i, x) + b;
%   fval: objective funcation value at the calculated solution
%   exitFlag:
%       0: exceed the maximum iteration number
%       1: succeed to find a local minimum;
% version. 
%   2019.1.6 add a parameter of  repeat_num_initial_point 


% solve the program:
%
%   min_{w}   0.5|w|^2 + cp*\sum_{i:y_i==1} R_s(y_i*f(x_i))
%       + cu*\sum_{i:y_i==-1} R_s(f(x_i))
%
%   where labels for all y_i with the samples with missing labels are
%   marked  y_i=-1
%
%     R_s(t) =  0.5*min(1-s, max(0,1-t) ); where s = -1
%     f(x) = sum_{i=1}^n alpha_i*k(x_i,x) +b,  b=0
%     w = sum_i alpha_i Phi(x_i)

repeat_num_initial_point = problemArg('repeat_num_initial_point');

if isempty(repeat_num_initial_point) || repeat_num_initial_point<=0
    repeat_num_initial_point = 1;    
end    
if repeat_num_initial_point == 1    
    [sol,fval, exitFlag] = pu_CCCP_batch0(arg,X_col,y_total);
    return;    
end
    
% repeat_num_initial_point > 1    
fval_v = zeros(1,repeat_num_initial_point);
exitFlag_v = zeros(1,repeat_num_initial_point);
sol_c = cell(1,repeat_num_initial_point);
for i_repeat= 1:repeat_num_initial_point
    [sol_c{i_repeat},fval_v(i_repeat), exitFlag_v(i_repeat)] = pu_CCCP_batch0(arg,X_col,y_total);
end
[~,ind]  =  min(fval_v);
sol = sol_c{ind};
fval = fval_v(ind);
exitFlag = exitFlag_v(ind);

end

function [sol,fval, exitFlag] = pu_CCCP_batch0(arg,X_col,y_total)
[cp,cu,w_feature] = ...
    getArgument(arg,{'cp','cu','w'});
% lambda_max: maximum value of lambda at each epoch

[verbose,max_ite_CCCP_batch, decrease_factor_tolFun,decrease_factor_tolX,lambda_mode,n_ite_lambda,...
    tolFun,tolX, kernelType,r1,flag_low_rank_approx,tol_low_rank_approximation,flag_calculate_initial_point,...
    min_tolFun,min_tolX,flag_gpu_on,display,path_user_data,maxTrainSize,flag_check_cache_kernel_matrix,...
    flag_use_HessMult,algorithm_fmincon] = ...
    problemArg('verbose','max_ite_CCCP_batch','decrease_factor_tolFun','decrease_factor_tolX','lambda_mode','n_ite_lambda',...
    'tolFun', 'tolX',  'kernelType','r1','flag_low_rank_approx','tol_low_rank_approximation','flag_calculate_initial_point',...
    'min_tolFun','min_tolX','flag_gpu_on','display','path_user_data','maxTrainSize','flag_check_cache_kernel_matrix',...
    'flag_use_HessMult','algorithm_fmincon');

if ~isempty(maxTrainSize) && (length(y_total)>maxTrainSize || size(X_col,2)>maxTrainSize)
    error('Batch CCCP algorithm currently only support datsets which size less than %d.',maxTrainSize);
end

% % % if strcmpi(lambda_mode,'SPL')
% % %     lambda_mode = 0; % iterate lambda with Self-paced learning (SPL)
% % % else
% % %     lambda_mode = 1; % default value
% % % end

%%%
%   verbose 
%%%

n_case = length(y_total);  % number of total training samples
ind_target = y_total==1; % indices of the positive instances
ind_neg = y_total==-1;   % indices of the negative instances


% parameters

threshold_vary_bound = 2;
% if  average number of the vary bounds of targets in active set in recent iterations  <=  THIS ratio
%   then the bounds are viewed as stable

arg_quad = struct('TolFun',tolFun, 'TolX',tolX);

% % calculate the value of s_loss
% lambda_min = 0.0; % initial minimum value of lambda
%
% %lambda_increment = (lambda_max-lambda_min)/max(n_ite_lambda-1,1);
% lambda_increment = (lambda_max-lambda_min)/max(n_ite_lambda,1);
% % value of lambda  incresed each time
% if lambda_mode==0
% %    lambda= lambda_min;
%     lambda= lambda_increment; % start from a small value
% else % lambda_mode == 1 || lambda_mode == 'Fix'
%     lambda = lambda_max;
%     n_ite_lambda = 1; % ite_lambda  iterate 1 time in fix mode
% end
% s_loss =   1-lambda/c3;

s_loss = -1 ;

% initialization


% lower and upper bounds for optimization variable a_v
A_total_v = (-0.5*cu)*ones(n_case,1);
A_total_v(ind_target) = 0;
B_total_v = zeros(n_case,1);
B_total_v(ind_target) = 0.5*cp;

%rng(1,'twister');
rng('shuffle');
x0 = (rand(n_case,1)-0.5)*2;
x0 = proj_box(x0,A_total_v,B_total_v);
%x0 = zeros(n_case,1,'single');


%persistent  A_act_old B_act_old i_call v_vary_bound;
A_act_old =[];
B_act_old =[];
i_call = [];
v_vary_bound = [];
% A_act_old:  array, the lower bounds of active indices of targets in the previous call
% B_act_old:  array the upper bounds of active indices of targets in the previous call
% v_vary_bound: array of length  n_statistic_radius, consisting of the number
%      of varied bounds in recent calls
% i_call = mod(i_ite,n_statistic_radius)
%              with i_ite the number of call


% calculate the kernel matrix K or its Cholesky factor matrix G
alg_hash = 'MD5';
% check whether the kernel matrix or its cholesky factor matrix has
% existed
h_X = hash(X_col,alg_hash);
file_kernel_matrix_mat = [addFileSep(path_user_data) h_X '.mat'];



arg_chol = struct('kernelType',kernelType,'r1',r1,'tol',tol_low_rank_approximation,'w',w_feature);
hash_arg = hash_struct(arg_chol,alg_hash);% generate hash character of the parameters for calculating the kernel matrix and its factorization
flag_exist_cache_kernel_matrix = 0; % whether to use the cached kernel matrix (or its factorized  matrix)

if  flag_check_cache_kernel_matrix && exist(file_kernel_matrix_mat,'file')
    % check whether the arguments are the same with that of calculate  the
    %   stored kernel elements
    data_kernel = load(file_kernel_matrix_mat);
    
    if isfield(data_kernel,'hash_arg')  && strcmp(data_kernel.hash_arg,hash_arg)
        % the hash of the current parameters for calculating the kernels (and the
        % factorization) are the same with the stored hash
        if flag_low_rank_approx
            if isfield(data_kernel,'G') && ~isempty(data_kernel.G)
                G_total = data_kernel.G;
                flag_exist_cache_kernel_matrix = 1;
                if verbose>=2
                    fprintf(1,'Employ the  previous calculated Cholesky factorization of the kernel matrix with size %d-by-%d.\n',...
                        size(data_kernel.G,1),size(data_kernel.G,2));
                end
            end
        else % use the kernel matrix directly
            if isfield(data_kernel,'K') && ~isempty(data_kernel.K)
                K_total = data_kernel.K;
                flag_exist_cache_kernel_matrix = 1;
                if verbose>=2
                    fprintf(1,'Employ the  previous calculated  kernel matrix with size %d-by-%d.\n',size(data_kernel.K,1),size(data_kernel.K,2));
                end
            end
        end
    end
end

if flag_exist_cache_kernel_matrix && verbose>=2
    fprintf(1,'The kernel elements (or its factorization) stored in %s \n',file_kernel_matrix_mat);
end

%%%%
% % % fwritef(1,'flag',flag_exist_cache_kernel_matrix,'','h_X',h_X,'', 'hash_arg',hash_arg,'','r1',r1,'');
%%%%

if ~flag_exist_cache_kernel_matrix
    if verbose>=2
        fprintf(1,'CCCP_batch: X_col: %d-by_%d\n',size(X_col,1),size(X_col,2));
    end
    % do not use employed caching kernel matrix, then calculate the kernel matrix or its factorization.
    if flag_low_rank_approx
        %%arg_chol = struct('kernelType',kernelType,'r1',r1,'tol',tol_low_rank_approximation,'w',w_feature);
        t_start = tic;
        [G_total,r]= chol_kernel_matrix(X_col',arg_chol);
        elapseTime = toc(t_start);
        if verbose>=2
            fprintf(1,'Finished to do Cholesky factorization of the kernel matrix, elapse time: %.2fs.\n',elapseTime);
            fprintf(1,'The rank of the Cholesky matrix: r = %d \n',r);
        end
        % save the factorization
        date_str = datestr(now,30);
        saveData(file_kernel_matrix_mat,'G',G_total,'r',r,'date_str',date_str,'hash_arg',hash_arg,'hash_X',h_X);
    else
        t_start = tic;
        K_total = kernelMatrix_OnceaLine(kernelType,X_col,X_col,r1,w_feature);
        elapseTime = toc(t_start);
        if verbose>=2            
            fprintf(1,'Finished to calculate the %d-by-%d kernel matrix, elapse time: %.2f.\n', size(K_total,1),size(K_total,2),elapseTime);
        end
        % save the kernel matrix
        date_str = datestr(now,30);
        saveData(file_kernel_matrix_mat,'K',K_total, 'date_str',date_str,'hash_arg',hash_arg,'hash_X',h_X);
    end
    
end


% 0. Precalculation: Calculate an initial solution  by calling the procedure itself
n_sub = round( min(max(500,n_case/3),n_case)); %
if n_sub < n_case && flag_calculate_initial_point
    flag_use_gpu = 0; % do not use gpu in precalculation
    i_sub = randperm(n_case,n_sub);
    if flag_low_rank_approx
        G= G_total(i_sub,:);
        G_t = G';
    else
        K = K_total(i_sub,i_sub); % sample a sub kernel matrix
    end
    y = y_total(i_sub);
    A_v = A_total_v(i_sub);
    B_v = B_total_v(i_sub);
    x0 = zeros(n_sub,1);
    [xk,fval_k,exitFlag_quad] = solve_dual_CSVM_FoApL(x0,arg_quad);
    % set x0
    x0 = zeros(n_case,1);
    x0(i_sub) = xk;
    if verbose>1
        fprintf(1,'Calculate an initial solution. \t exitFlag: %d \n',exitFlag_quad);
    end
end

if flag_low_rank_approx
    G= G_total;
    G_t = G';
else
    K = K_total;
end

flag_use_gpu = flag_gpu_on && gpuDeviceCount()>0; % use gpu acceleration

if flag_use_gpu
    gpu_v = gpuDevice(1);
    if verbose>0
        fprintf(1,'GPU Device %i is open. It has ComputeCapability %s \n', gpu_v.Index,gpu_v.ComputeCapability);
    end
    if flag_low_rank_approx
        G = gpuArray(single(G));
        G_t = gpuArray(single(G_t));
    else
        K = gpuArray(single(K_total));
    end
end

y = y_total;
A_v = A_total_v;
B_v = B_total_v;


% ---------  begin of the batch CCCP procedure     -----------------
% % % for ite_lambda = 1:n_ite_lambda
for ite_lambda = 1:1
    % % %     if verbose>0
    % % %          fprintf(1,'\n =====   ite  %d: lambda: %.3f ===== \n',ite_lambda,lambda);
    % % %     end
    ite_out = 1;
    while 1
        % 1. solve the dual quadratic programming
        [xk,fval_k,exitFlag_quad] = solve_dual_CSVM_FoApL(x0,arg_quad);
        
        % 2.1 update eta
        if flag_low_rank_approx
            % % %             %f_target =   G(ind_target,:)*(G_t*xk);
            f_v =   G*(G_t*xk);
        else
            % % %             %f_target =   K(ind_target,:)*xk;
            f_v =   K*xk;
        end
        if flag_use_gpu
            f_v = gather(f_v);
        end
        % if y_i*f(x_i) < s_loss, then for i \in Omega+
        %   eta_i = 1;
        % otherwise
        %   eta_i = 0;
        % end
        % % %         %eta_target = f_v < s_loss;
        eta_v = y_total.*f_v < s_loss;
        
        %%%
        %nnz(y_total.*f_v < 0)
        
        %%%
        
        % 2.2 update bounds A_v, B_v
        %                     A_i =         -0.5*cp*eta_i,
        %                     B_i = 0.5*cp  -0.5*cp*eta_i,   y_i =+1
        %                     A_i =-0.5*cu + 0.5*cu*eta_i,
        %                     B_i =          0.5*cu*eta_i,   y_i = -1
        
        A_v(ind_target) =         - 0.5*cp * eta_v(ind_target);
        B_v(ind_target) =  A_v(ind_target) + 0.5 * cp;
        A_v(ind_neg)    =  -0.5*cu + 0.5*cu* eta_v(ind_neg);
        B_v(ind_neg)    =  A_v(ind_neg) + 0.5*cu  ;
        
        % stopping criteria
        [flag_bound_converge,n_vary_bound_v]= rule_converge_bound();
        
        if verbose>1
            fprintf(1,'ite: %d\t  fval: %.2f\t n_var_bound: [%d, %d], exitFlag_quad: %d TP: %d\t , TN:%d\t \n',ite_out,obj_foapl(xk), ...
                n_vary_bound_v(1), n_vary_bound_v(2),exitFlag_quad, nnz(y_total==1 .*(f_v>0)), nnz(y_total==-1 .*(f_v<0)) );
            fprintf(1,'arg_quad.TolFun: %.2e,\t arg_quad.TolX: %.2e\n',arg_quad.TolFun,arg_quad.TolX);
        end
        
        ite_out = ite_out + 1;
        if ite_out > max_ite_CCCP_batch
            exitFlag = 0; % exceed the maximum iteration number
            break;
        end
        if flag_bound_converge % bounds A_v and B_v are stable
            exitFlag = 1;
            break;
        end
        
        % 3. update x0 and the algorithm parameters
        x0 = xk;
        arg_quad.TolFun = max(arg_quad.TolFun * decrease_factor_tolFun, min_tolFun);
        arg_quad.TolX = max(arg_quad.TolX * decrease_factor_tolX, min_tolX);
    end
    %     % update lambda
    %     if lambda_mode==0 && ite_lambda < n_ite_lambda
    %                 % lambda_mode==0: SPL mode
    %                 % ite_lambda < n_ite_lambda: at the last iteration of
    %                 %        ite_lambda, do not update lambda and s_loss
    %         % update lambda, s_loss
    %         lambda = lambda + lambda_increment;
    %         s_loss = 1-lambda/c3;
    %     end
end % end the iteration of lambda

%---------- end of the batch CCCP procedure --------

% outputs:
sol.alpha = xk;
sol.b = 0; %  SVM in the primal: f(x) = \sum_{i} \alpha_i k(x_i, x);
%%%fval_dual = - fval_k + c3*sum(y(ind_target));
fval = obj_foapl(xk);
if verbose>=1
    %fprintf(1, 'fval_opt: %.3f\n',fval);
    fprintf(1,' TP_train: %d\t , TN_train:%d\t \n', ...
        nnz(y_total==1 .*(f_v>0)), nnz(y_total==-1 .*(f_v<0)) );
end

% % %         % - fval_k: the quadratic programming minimizes an convex func.
% % %         %   which negative is the original objective func except
% % %         %       the constant c3*sum(y(ind_target));

    function [x,fval,exitflag] = solve_dual_CSVM_FoApL(x0,arg_quad)
        % solve the dual programming of CSVM FoApL
        % Inputs:
        %  x0: the initial point, set [] if not specified the initial
        %     point;
        % arg_quad: optional, stucture of the parameters
        %    .TolFun:  Termination tolerance on the function value, a positive scalar.
        %           Apply for all algorithms, except active-set
        %       For a 'trust-region-reflective' equality-constrained problem, the default value is 1e-6.
        %       For a 'trust-region-reflective' bound-constrained problem, the default value is 100*eps, about 2.2204e-14.
        %       For 'interior-point-convex', the default value is 1e-8.
        %   .TolX:     % Termination tolerance on x, a positive scalar.
        %       For 'trust-region-reflective', the default value is 100*eps, about 2.2204e-14.
        %       For 'interior-point-convex', the default value is 1e-8.
        %
        % Outputs:
        %    x: the solution
        % fval: objective function value
        % flag: 1: Function converged to the solution x.
        %   0: Number of iterations exceeded options.MaxIter.
        %  -2:   Problem is infeasible.
        %  -3:   Problem is unbounded.
        
        
        % the dual programming
        %        max_{alpha}  -0.5* <alpha,K*alpha> + <alpha,y> + constant
        %    <=> min_{alpha}  0.5* <alpha,K*alpha> - <alpha,y> - constant
        %       s.t.         A_i <= alpha_i <=B_i,  for all i
        %                     A_i =         -0.5*cp*eta_i,
        %                     B_i = 0.5*cp  -0.5*cp*eta_i,   y_i =+1
        %                     A_i =-0.5*cu + 0.5*cu*eta_i,
        %                     B_i =          0.5*cu*eta_i,   y_i = -1
        
        % set program options
        %         options = optimoptions('quadprog', 'Algorithm','interior-point-convex','Display','off');
        %         if isempty(arg_quad)
        %             if isfield(arg_quad,'TolFun') && ~isempty(arg_quad.TolFun)
        %                 optimoptions(options, 'TolFun',arg_quad.TolFun)
        %             end
        %             if isfield(arg_quad,'TolX') && ~isempty(arg_quad.TolX)
        %                 optimoptions(options, 'TolX',arg_quad.TolX)
        %             end
        %         end
        
        if flag_use_HessMult
            options = optimset('TolFun',arg_quad.TolFun, 'TolX',arg_quad.TolX,'Display',display, ...%'MaxFunEvals',max(4*l,3000),...
            'GradObj','on','Algorithm',algorithm_fmincon ,...
            'Hessian','user-supplied','SubproblemAlgorithm','cg','HessMult',@HessMultFcn, 'DerivativeCheck','off');
        else
            options = optimset('TolFun',arg_quad.TolFun, 'TolX',arg_quad.TolX,'Display',display, ...%'MaxFunEvals',max(4*l,3000),...
                'GradObj','on','Algorithm',algorithm_fmincon   );
        end
        
        
        nonlcon=[];
        A = [];
        b = [];
        Aeq = [];
        beq = [];
        [x,fval,exitflag] =  fmincon(@fun,x0,A,b,Aeq,beq,A_v,B_v,nonlcon,options);
        %         [x,fval,exitflag] =  quadprog(K,-y,A,b,Aeq,beq,A_v,B_v,x0,options);
    end % end sub-function solve_dual_CSVM_FoApL

    function [fx,gd] = fun(alpha)
        
        if flag_use_gpu
            alpha = gpuArray(single(alpha));
        end
        if flag_low_rank_approx
            z = G*(G_t*alpha);
        else
            z = K*alpha;
        end
        fx = 0.5*sum(alpha.*z) - sum(y.*alpha);
        gd = z-y;
        if flag_use_gpu
            fx = double(gather(fx));
            gd = double(gather(gd));
        end
    end

    function w = HessMultFcn(x,lambda,v)
        % Inputs:
        %   lambda:  the Lagrange multiplier (computed by fmincon)
        %    v:     a vector of size n-by-1.
        % Outputs: w : the product H*v, where H is the Hessian of the Lagrangian at x,
        if flag_use_gpu
            v = gpuArray(single(v));
        end
        if flag_low_rank_approx
            w = G*(G_t*v);
        else
            w = K*v;
        end
        if flag_use_gpu
            w = double(gather(w));
        end
    end

    function obj_val = obj_foapl(alpha_v)
        % calculate the objective function value at xk
        %  with the instances contained in current working set
        
        %   min_{w}   0.5|w|^2 + cp*\sum_{i\in P} H_s(y_i*f(x_i))
        %       + (cu)*\sum_{i\in U} R_s(y_i*f(x_i))
        %   <==>
        %   min_{alpha}   0.5<alpha,K*alpha> + cp*\sum_{i\in P} H_s(y_i*f(x_i))
        %       + (cu)*\sum_{i\in U} R_s(y_i*f(x_i))
        %
        %   where  P = {j | y_j ==+1}; U = {j | y_j ==-1};
        %
        %     R_s(t) =   min(1, max(0,0.5-0.5*t) );
        %     f(x) = sum_{i=1}^n alpha_i*k(x_i,x) +b,  b=0
        %     w = sum_i alpha_i Phi(x_i)
        
        % calculate the function value f(x_i)
        if flag_low_rank_approx
            y_hat = G*(G_t*alpha_v);        % predicted value for all the instances
        else
            y_hat = K*alpha_v;
        end
        if flag_use_gpu
            y_hat = gather(y_hat);
        end
        % calculate the objective function value
        obj_val = 0.5*  dot(alpha_v,y_hat)  + ...
            cp * sum(min(1,  max(0,0.5+0.5*y_hat(ind_neg))) ) + cu* sum(  min(1, max(0,0.5 - 0.5*y_hat(ind_target)) )  );
    end


    function [flag_converge,n_bound_vary]= rule_converge_bound(reset)
        %����check whether the bounds of A_v and B_v of the active set
        %     varies little in recent iterations
        % Input:
        %  reset: optional, 1 or 0, whether to reset to state of the
        %   funtion, i.e., clean and neglect the information in  previous
        %   iterations
        % Outputs:
        %  flag_converge: 1 or 0, whether the bound A_v and B_v of the
        %    targets in active set are nearly not changed.
        %  n_bound_vary: a 4-by-1 column vector
        %    n_bound_vary(1): the number of the bounds (A_v and B_v) that
        %       varies in current inner iteration
        %     n_bound_vary(2): the total number of the bounds (A_v and B_v) that
        %       varies in the near 5 iterations
        
        % % %          persistent  A_act_old B_act_old i_call v_vary_bound;
        
        % A_act_old:  array, the lower bounds of active indices of targets in the previous call
        % B_act_old:  array the upper bounds of active indices of targets in the previous call
        % v_vary_bound: array of length  n_statistic_radius, consisting of the number
        %      of varied bounds in recent calls
        % i_call = mod(i_ite,n_statistic_radius)
        %              with i_ite the number of call
        
        n_statistic_radius = 5; % number of recent iterations to be calculated
        
        
        if nargin==0
            reset = 0;
        end
        n_bound_vary = zeros(2,1);
        if isempty(A_act_old) || reset
            A_act_old = A_v;
            B_act_old = B_v;
            i_call = 0;
            v_vary_bound = inf(n_statistic_radius,1);
            % initialize the number of varied bounds as positive infty
            flag_converge = 0;
            return
        end
        
        % calculate the number of changed lower bounds and upper bounds on
        %   the indices i_act_old
        i_call = mod(i_call,n_statistic_radius)+1;
        % the value of i_call locates between [1,n_statistic_radius]
        v_vary_bound(i_call) = nnz(A_act_old ~= A_v) ...
            + nnz(B_act_old ~= B_v);
        
        
        % determine whether the stable rule satisfied
        % Rule 1:
        %   if the total number of the bounds A_v and B_v that changes in
        %       recent iterations less than a threshold, then
        %       the iterations are viewed as stable;
        
        flag_converge = mean(v_vary_bound) < threshold_vary_bound;
        
        n_bound_vary(1) = v_vary_bound(i_call);
        n_bound_vary(2) = sum(v_vary_bound);
        % update the variables
        A_act_old = A_v;
        B_act_old = B_v;
    end
end
