function f_v = ramp(t_v)
% ramp loss 
    f_v = min(1,max(0,0.5-0.5*t_v));
end