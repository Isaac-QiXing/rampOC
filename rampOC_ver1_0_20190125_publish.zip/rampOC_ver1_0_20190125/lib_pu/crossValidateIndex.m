function index = crossValidateIndex(n_total_sample,k,varargin) 
% generate k-fold cross validation index
%  Inputs��
%   n_total_sample: number of total training samples (N>=k)
%   k: number of fold (k>=2)
%   varargin{1}: maximum number of samples for cross validation, default
%   [];
%   varargin{2}: flag_equal_fold_size: 1 or 0, whether ensures each fold 
%       have the common size, default 0; 
%  Outputs:
%   index: a struct array of length k, with two fields
%       index(i).train: the indices for training 
%       index(i).test: the indices for validation, i=1,...,k
%           the indices for   index(i).train and   index(i).test are 
%           a  partition of 1:N  
%           and index(i).test have indices of about 1/k*N;
% version: 
%   2018.10.3 add an optional input parameter of 'flag_equal_fold_size'
%   
if nargin>=3
    n_max_sample_validation = varargin{1};
else
    n_max_sample_validation = [];
end
if nargin>=4
    flag_equal_fold_size = varargin{2};
else
    flag_equal_fold_size = 0;
end
    

if k<2
    error('The number of folds should be greater than 1.');
end

% determine the number of samples, N, for cross validation
if isempty(n_max_sample_validation)
    N = n_total_sample;
else
    N = min(n_total_sample,n_max_sample_validation);
end
if N<k
    error('The number of training samples should greater than the number of folds.');
end
if flag_equal_fold_size
    % reset N such that N is exactly divisible by k
    N = floor(N/k)*k;
end


len_fold = floor(N/k); % number of indices in each fold
len_fold_last  = N - (len_fold)*(k-1); % number of indices in the last fold

% assign the starting and ending index of each fold
ind_start_v = 1:len_fold:N-len_fold_last+1; % starting index of each fold
ind_end_v = ind_start_v + len_fold-1; % ending index of each fold
ind_end_v(end) = N; 


% assign indices for training and test
index = struct('train',cell(k,1),'test',[]);
ind_v = randperm(n_total_sample,N);
for ii=1:k
    index(ii).test = ind_v(ind_start_v(ii):ind_end_v(ii));
    if ii>1 && ii<k
        v = [1:ind_end_v(ii-1), ind_start_v(ii+1):N];
    elseif ii==1
        v = ind_start_v(ii+1):N;
    else % ii==k
        v = 1:ind_end_v(ii-1);
    end
    index(ii).train = ind_v(v);
end

end