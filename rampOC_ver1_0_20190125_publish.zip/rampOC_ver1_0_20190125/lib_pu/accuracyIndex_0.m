function [acc,num,varargout] = accuracyIndex_0(indexRank,y)
% calculate the accuracy index
%
% Inputs:
%  indexRank: the predicted discriminant function value of the samples;
%  y: a column vector consisting of the labels,  consisting of +1 and -1;
% Outputs:
%  num: array of accuracy structure with the same length as
%    arg.selectedTarget
%   .TP : number of true positives
%   .FP : number of false positives
%   .FN : number of false negative
%   .TN : number of true negative
%  acc: array of accuracy structure
%   .FDR: false discovery rate: FP/(FP+TP)
%   .TPR: true positive rate:  TP/(TP+FN)
%   .FPR: false positive rate: FP/(FP+TN)
%  varargout{1}: id, array of a structure with the same fields as NUM; indexing the
%      selected samples

if   length(y)~=length(indexRank)
    error('The length of the #1 and #2 should equal.');
end

% calculate the accuracies based on the value of arg.selectdTarget
len_sel = 1;
num = struct('TP',num2cell(zeros(len_sel,1)),'FP',0,'FN',0,'TN',0);
id =  struct('TP',cell(len_sel,1),'FP',[],'FN',[],'TN',[]);
acc = struct('FDR',num2cell(zeros(len_sel,1)),'TPR',0,'FPR',0);

fieldname_num = fieldnames(num);

if nargout>=3
    id(1).TP = find(indexRank>=0 & y ==1);
    id(1).FP = find(indexRank>=0 & y ==-1);
    id(1).TN = find(indexRank<0  & y ==-1);
    id(1).FN = find(indexRank<0  & y == 1 );
    varargout{1} = id;
    % assign num(1)
    for k=1:length(fieldname_num)
        fieldName = fieldname_num{k};
        num(1).(fieldName) = length(id(1).(fieldName));
    end
else % nargour<=2
    % calculate the field values of NUM
    num(1).TP = nnz(indexRank>=0 & y ==1);
    num(1).FP = nnz(indexRank>=0 & y ==-1);
    num(1).TN = nnz(indexRank<0 & y ==-1);
    num(1).FN = nnz(indexRank<0 & y == 1 );
end

% assign acc(1)
acc(1).FDR = num(1).FP/(num(1).FP + num(1).TP);
acc(1).TPR = num(1).TP/(num(1).TP + num(1).FN);
acc(1).FPR = num(1).FP/(num(1).FP + num(1).TN);
end

