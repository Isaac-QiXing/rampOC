function [acc_opt,par_opt]= foapl_crossValidate(matTrainFile, fold_k,varargin)
% cross validation to choose a good group of parameter values
% Inputs:
%  trainFile: mat file name containing the data for training
%   fold_k: a positive integer (fold_k>=2), number of folds;
%  varargin: the names and values of arguments of for training  the model
%    varargin{2*i-1}: a string, the argument name;
%    varargin{2*i}:  a vector indicating the tested values of the argument
%     of varargin{2*i-1}; for i=1, 2, ...
%   
% Outputs:
%   acc_opt: the optimal reach (average) accuracy on validation sets
%   par_opt: a cell array indicating the parameter values with optimal accuracy
% Usage example:
%    [Par,Acc,par_opt]= foapl_crossValidate(trainFile, 5, 'lambda',[0.1 1.0 5.0],'r1',[0.1 0.2 1.0]);




verbose = 1; %problemArg('verbose');

len_arg = length(varargin);
if mod(len_arg,2)~=0
    error('the input parameter-values should be given as  ''parameter-1,value-1,...,parameter-N,value-N'' format)' );
end


par_name_c = varargin(1:2:len_arg);
par_val_c =varargin(2:2:len_arg);


n_parVal_v = cellfun(@length, varargin(2:2:len_arg));
% number of tested values for each parameter
n_parVal_total = prod(n_parVal_v); % total number of group of parameter values to test

% initialization
n_par = len_arg/2; % number of parameters
par_name_value = cell(2*n_par,1); % parameter name and value cell, for userSetting()
par_name_value(1:2:end) = par_name_c;

Acc_m = zeros(n_parVal_total,fold_k);  % save the accuracy on each fold
Par_c = cell(n_parVal_total,1);
% % % num_st = struct('TP',cell(n_parVal_total,fold_k),'FP',[],'TN',[],'FN',[]);
% group of parameters to test

% assign the parameter values to test
ind_v = cell(n_par,1);
par0_c = cell(n_par,1); % store a group of parameter values
for i_par = 1:n_parVal_total
    % assign each group of parameter values
    [ind_v{1:n_par}]  = ind2sub(n_parVal_v,i_par); % ind_v: index of vector form for i_par
        % receive multiple outputs by cell array
    for k=1:n_par
        par0_c{k} =  par_val_c{k}(ind_v{k});
    end
    Par_c{i_par}= par0_c;
% % %     %%%
% % %     fwritef(1,'i_par',i_par,'', 'ind_v',ind_v,'' ,'Par_c',Par_c,'' ,'n_parVal_v',n_parVal_v,'');
% % %     %%%
end

 

% load data
s = load(matTrainFile,'X','y','ind','X_feature');

[n_sample,m] = size(s.X); % m: number of features

if n_sample<fold_k
    error('The number of training samples should greater than the number of folds.');
end
if verbose>0
    fprintf(1,'Cross validation: %d-fold, %d-group of parameters.\n',fold_k,n_parVal_total);
end

% generate indices of training set and validation set
index = crossValidateIndex(n_sample,fold_k);
date_str = datestr(now,30);
path_str = [pwd filesep];
matTrainFile = [path_str date_str '_crossVal_train.mat'];
matTestFile =  [path_str date_str '_crossVal_test.mat'];
matScoreFile = [path_str date_str '_crossVal_score.mat'];
for i_fold = 1:fold_k
    % save the data to tempary train file and validation file
    if verbose > 0
        fprintf(1,' fold %d/%d:\t',i_fold,fold_k);
    end
    saveData(matTrainFile,'X',s.X(index(i_fold).train,:),'y',s.y(index(i_fold).train),...
        'sizeX',[length(index(i_fold).train), m],'ind',index(i_fold).train,'X_feature',s.X_feature);
    saveData(matTestFile,'X',s.X(index(i_fold).test,:),'y',s.y(index(i_fold).test),...
        'sizeX',[length(index(i_fold).test), m],'ind',index(i_fold).test,'X_feature',s.X_feature);
    
    for i_par = 1:n_parVal_total
        % loop all the parameter  values
        if verbose > 0
            fprintf(1,'+');
        end
        % set the values of the group of parameters
        par0_c = Par_c{i_par} ;
        par_name_value(2:2:end) = par0_c;
        userSetting(par_name_value);
% % %         %%%
% % %         fwritef(1,'',par_name_value,'');
% % %         %%%%
        % train the model and evaluate the accuracy on validation set
        foapl_solve('-f','2', matTrainFile,matTestFile,matScoreFile)
        % calculate the average accuracy on validation sets
        sc = load(matScoreFile, 'score_test');
        [~,num]  = accuracyIndex_0(sc.score_test,s.y(index(i_fold).test));
        %%%
        if i_par==1 && i_fold==1
            % initialize num_st
            num_st(n_parVal_total,fold_k) = num;                
        end
        num_st(i_par,i_fold) = num;
         
        %Acc_m(i_par,i_fold) = (num.TP + num.TN)/length(index(i_fold).test);
        Acc_m(i_par,i_fold) =  num.TP /max(num.TP + num.FP,1); %  
    end % end loop of parameters
    if verbose > 0
        fprintf(1,'\n');
    end
end % end loop of i_fold

% optimal parameter
acc_v = mean(Acc_m,2);
[acc_opt,i_opt] = max(acc_v);
par_opt = Par_c{i_opt};

%%%%
save('temp20180808.mat','Acc_m','Par_c','num_st','i_opt','acc_opt');
%%%

% delete tempary files
if exist(matTrainFile,'file')
    delete(matTrainFile);
end
if exist(matTestFile,'file')
    delete(matTestFile);
end
if exist(matScoreFile,'file')
    delete(matScoreFile);
end
end
