function    [y_pu,ind_train] =  pu_label(y,classPrior,varargin)
% generate labels of PU-learning instances
% Inputs:
%   y: a column vector of the labels of classical binary classification  problem
%   classPrior: a constant sclar in (0,1)
%    if mode_str=='pu', it indicates the proposion of the  positive instances among those of the missing labels
%    if mode_str=='pn', it indicates the proposion of the observed labels to total labels
%    if mode_str=='p', it indicates the proposion of the observed positive labels to total positive labels
%    if mode_str=='n', it indicates the proposion of the observed negative labels to total negative labels
%    if mode_str=='n_reverse', it indicates the propostion of the correct negative labels to total negative labels
%    if mode_str=='p_reverse', it indicates the propostion of the correct positive labels to total postive labels
%    if mode_str=='pn_reverse', it indicates the propostion of the correct labels to total labels
%    if mode_str =='normal', the function does nothing, y_pu =y; ind_train = [1:length(y)]';
%   varargin{1}:
%    mode_str: optional, a string indicating the mode to produce labels,   default value: 'pu',
%       it has the following values
%     'pu':  only part of positive labels (+1) are known, all the other labels are missing
%     'pn': only part of positive labels and negative labels are known
%     'p':  only part of positive labels are known, all the other labels are missing
%     'n': only part of  negative labels are known, all the other labels are missing
%     'n_reverse': all the labels are observed, but part of the -1 labels would be set to
%     +1, in this case +1 labels are not trustworthy
%     'p_reverse': all the labels are observed, but part of the +1 labels would be set to
%       -1, in this case -1 labels are not trustworthy
%     'pn_reverse': all the labels are observed, but part of the positive labels and negative
%        labels would be reversed
%     'normal': the function does nothing, y_pu =y; ind_train = [1:length(y)]';
% Outputs:
%   y_pu: a column vector with the length less than or equal to y,
%     if mode_str=='pu', it  consists of 1 and -1  with -1 indicating a missing label.
%     if mode_str=='pn','p' or 'n', it consists of 1, -1 and 0, with 0 indicates the missing label,
%           length(y_pu)==length(y);
%     if mode_str == 'n_reverse',  'p_reverse', 'pn_reverse' or 'normal'
%           it  consists of 1 and -1, length(y_pu)==length(y);
%
%   ind_train: a clumn vector of 1 or 0 with the same size as y,
%      1: indicating the instance is selected as training
%  NOTE that y_pu ~= y(ind_train), since part of +1 labels are
%   missing and labeled -1;
%
% version
%   2018.12.28 add mode_str 'p' and 'n'
%   2018.12.26 add other mode_str to generate the labels
%
%   2018.8.12  first version
ind_pos_v = find(y==1) ;
ind_neg_v = find(y==-1);

n_pos = length(ind_pos_v); % total number of positive instances for training
n_neg = length(ind_neg_v); % total number of negative instances for training
n_y = length(y);

if n_pos<1 || n_pos>=n_y
    error('No positive or negative instances provides');
end
if n_pos + n_neg < n_y
    error('The labels should be a vector with elements of 1 or -1.');
end
if classPrior<=0 || classPrior >=1
    error( 'It should be ensured that 0<classPrior<1.');
end

if nargin<=2
    mode_str = 'pu';
else
    mode_str = varargin{1};
end
mode_str = strtrim(lower(mode_str));

switch mode_str
    case 'normal'
        ind_train = (1:n_y)';
        y_pu = y;
    case 'pn' %select part of positive labels and negative labels 
        n_neg_loss = ceil(n_neg * (1-classPrior));    % number of lost negative labels 
        n_pos_loss= ceil(n_pos * (1-classPrior));    % number of lost positive labels 
        ind_neg_loss = randperm(n_neg,n_neg_loss);
        ind_pos_loss = randperm(n_pos,n_pos_loss);
        ind_train = (1:n_y)';
        y_pu = y;
        y_pu(ind_neg_v(ind_neg_loss)) = 0;  %   
        y_pu(ind_pos_v(ind_pos_loss)) = 0;  %  missing labels are assigned 0 
     case 'p' %select part of positive labels labels, all the other labels are missing         
        n_pos_loss= ceil(n_pos * (1-classPrior));    % number of lost positive labels        
        ind_pos_loss = randperm(n_pos,n_pos_loss);
        ind_train = (1:n_y)';
        y_pu = y;
        y_pu(y==-1) = 0;        % all the negative labels are missing
        y_pu(ind_pos_v(ind_pos_loss)) = 0;  % the missing positive labels are assigned 0 
     case 'n' %select part of negative labels, all the other labels are missing 
        n_neg_loss = ceil(n_neg * (1-classPrior));    % number of lost negative labels          
        ind_neg_loss = randperm(n_neg,n_neg_loss); 
        ind_train = (1:n_y)';
        y_pu = y;
        y_pu(y==1) = 0;  %   % all the positive labels are missing
        y_pu(ind_pos_v(ind_neg_loss)) = 0;  % the missing negative labels are assigned 0 
      
    case  'n_reverse'   
        %  select certain number of -1 labels and reset them as +1
        n_neg_rev = ceil(n_neg * (1-classPrior));    % number of negative labels to reset
        ind_neg_rev = randperm(n_neg,n_neg_rev);
        ind_train = (1:n_y)';
        y_pu = y;
        y_pu(ind_neg_v(ind_neg_rev)) = 1;   
    case  'p_reverse'
        n_pos_rev = ceil(n_pos * (1-classPrior));    % number of positive labels to reset
        ind_pos_rev = randperm(n_pos,n_pos_rev);
        ind_train = (1:n_y)';
        y_pu = y;
        y_pu(ind_pos_v(ind_pos_rev)) = -1;    
    case  'pn_reverse'
        n_neg_rev = ceil(n_neg * (1-classPrior));    % number of negative labels to reset
        n_pos_rev = ceil(n_pos * (1-classPrior));    % number of positive labels to reset
        ind_neg_rev = randperm(n_neg,n_neg_rev);
        ind_pos_rev = randperm(n_pos,n_pos_rev);
        ind_train = (1:n_y)';
        y_pu = y;
        y_pu(ind_neg_v(ind_neg_rev)) = 1;   
        y_pu(ind_pos_v(ind_pos_rev)) = -1;   
    otherwise    % 'pu'
        n_pos_pu = floor(0.5 * n_pos); %   number of positive instances for PU learning
        n_unlabel_pu = floor(min(n_neg/(1-classPrior),(n_pos-n_pos_pu)/classPrior));
        % number of unlabeled instance for PU learning
        n_pos_mixture = floor(n_unlabel_pu * classPrior);
        % number   positive instances cantained in the unlabeled instances
        n_neg_mixture = floor(n_unlabel_pu * (1-classPrior));
        % number   negative instances cantained in the unlabeled instances
        
        ind_pos_perm   = randperm(n_pos, n_pos_pu+n_pos_mixture);
        ind_neg_perm = randperm(n_neg,n_neg_mixture);
        
        ind_train = columnVec([ind_pos_v(ind_pos_perm); ind_neg_v(ind_neg_perm)] );
        y_pu =   [ones(n_pos_pu,1); -1* ones( n_pos_mixture+ n_neg_mixture,1) ];        
end

end