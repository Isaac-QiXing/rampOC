% test_plot_feature_image

clear
clc

dataset = 'data1'; % 'data3';

if strcmpi(dataset,'data1')
    dataPath = 'E:\data_oil_spill\data1\';
    dataFile = [dataPath 'data1_downsampling_240000_feature8.mat'];
else % data3
    dataPath = 'E:\data_oil_spill\data3\';
    dataFile = [dataPath 'sample60000_feature8.mat'];
end

% 1. load data and reshape
data_s = load(dataFile,'X','Y','n_row','n_col');

n_dim = size(data_s.X,2);
X = reshape(data_s.X,data_s.n_row, data_s.n_col, n_dim);
Y = reshape(data_s.Y,data_s.n_row, data_s.n_col);



% 2. save feature images
parImage.path = [addFileSep(dataPath) 'featureImage8']; % path to save feature images
plot_feature_image(X,'X',parImage);

plot_feature_image(Y,'Y',parImage);
