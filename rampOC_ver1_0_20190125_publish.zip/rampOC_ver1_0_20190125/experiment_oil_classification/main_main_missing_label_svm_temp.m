% main_main_missing_label_svm_temp

clear 
clc

dataset2_c =  { 'data3', 'data1'};

for iii_set = 1:length(dataset2_c)
    dataset = dataset2_c{iii_set};
    main_missing_label_svm
end

