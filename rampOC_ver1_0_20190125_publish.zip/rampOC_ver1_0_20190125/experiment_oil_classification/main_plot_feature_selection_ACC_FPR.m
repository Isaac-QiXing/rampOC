% main_plot_feature_selection_ACC_FPR

% dataset 3
Acc = [...
0.933 
0.991 
0.995 
0.997 
0.993 
0.992 
0.992 
0.992 
];

FPR = [...
1.000 
0.075 
0.015 
0.030 
0.060 
0.090 
0.090 
0.075 
]; 

% data set 1
Acc_1 = [...
0.898 
0.954 
0.956 
0.964 
0.963 
0.957 
0.957 
0.957 
];

FPR_1 = [...
1.000 
0.039 
0.059 
0.078 
0.098 
0.088 
0.088 
0.098 
]; 

n_feature = [1 2 4 8 12 16 18 19]';


plot(n_feature,Acc_1,'-o' );
%saveas(gcf,'feature_role_dataset1');
hold on
plot(n_feature,Acc,'-.s' );
hold off
legend('Acc on dataset1','Acc on dataset2');
xlabel('Number of features');
ylabel('Accuracy');
saveas(gcf,'feature_role_acc');



