% main_load_data

dataPath = 'E:\data_oil_spill\data1\';
dataSet = 'data1';
inputFile = 'X.tif';
labelFile = 'Y.tif';
argDownSampling.size =   [600 400];

flag_plot_feature_image = 0;

% load data
X = imread([dataPath inputFile]);
Y = imread([dataPath labelFile]);
Y = double(Y);
Y(Y==0)=-1;

% down sampling
[X_output,Y_output] = figure_sampling(X,Y,argDownSampling);

outputFileName = [dataSet '_downsampling'];
outputFile_mat = [dataPath outputFileName '.mat'];
saveData(outputFile_mat,'X',X_output,'Y',Y_output,'n_row',size(Y_output,1),'n_col',size(Y_output,2));

% output basic information
n_oil = nnz(Y==-1);
n_water = nnz(Y==1);
fwritef(1,'n_oil',n_oil,'','n_water',n_water,'');

% save featue images
if flag_plot_feature_image
    parImage.path = [addFileSep(dataPath) 'featureImage']; % path to save feature images
    plot_feature_image(X_output,'X',parImage);
    plot_feature_image(Y_output,'Y',parImage);
end
