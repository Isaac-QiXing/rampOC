% main_produceSampleData

% data1

dataPath = 'E:\data_oil_spill\data1\';
dataSet = 'data1';
par.actRow = []; % all the rows are selected rows, if set it []
par.actCol = []; % all the columns are selected columns, if set it []
feature_order = [10,16,15,19,1,11,3,14,18,17,4,12,13,2,7,6,8,5,9];
argDownSampling.size =   [120 80];  % downSampling size,  do no operate down-sampling if set it [];
outputFileName = [dataSet '_sample9600'];
% argDownSampling  =   [];  % downSampling size,  do no operate down-sampling if set it [];
% outputFileName = [dataSet '_sample240000'];
matDataFile = [dataPath dataSet '_downsampling' '.mat'];

% dataPath = 'E:\data_oil_spill\data3\';
% dataSet = 'data3';
% par.actRow = [100:300];
% par.actCol = [100:350];
% argDownSampling.size =  [80 125]; % downSampling size,  do no operate down-sampling if set it [];
% feature_order = [18,14,15,10,13,1,17,12,19,3,8,16,9,5,7,2,6,4,11];


feature_selected_ratio_v = [0.05 0.1 0.2 0.4 0.6 0.8 0.9 1.0];

n_ratio = length(feature_selected_ratio_v);
arg.actFeature = cell(1,n_ratio);
for i_ratio=1:n_ratio
    sel_ratio=feature_selected_ratio_v(i_ratio);
    sel_num  = ceil(length(feature_order)*sel_ratio); % number of selected features
    
    arg.actFeature{i_ratio} = feature_order(1:sel_num);
end

produceSampleData(matDataFile,argDownSampling,arg);