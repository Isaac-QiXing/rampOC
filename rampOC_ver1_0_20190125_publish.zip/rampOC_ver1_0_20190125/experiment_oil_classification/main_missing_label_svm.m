% main_missing_label_svm

% version
%  2019.1.23
%   * run data 1 and data 3 with svm
% 2019.1.22 
%   * run  data 1 
% 2019.1.15 pm
%   * add a parameter n_repeat_test_set to test the performance on different test sets
%   * remove the parameter flag_use_total_sample_cv
% cross validation for test the model for different cases of missing/incorrect labels

% clear
% clc


% % % flag_classical_classification  =  1; %0; % classical binary classification
flag_scaling = 1; % whether do scaling to make each feature values zero-mean and unit variance
flag_have_a_try =  0;% 1; % 1;      % 1 or 0, whether just have a try to see whether the code run well
% % % flag_use_total_sample_cv = 0; % 1: use total samples for cross validation; 0: select part of samples as a train file for cv
train_test_rate = 2/8;

%  dataset = 'data3' ; % or 'data1'
solver = 'svm'; %'CCCP';

if flag_have_a_try
    %     fold_k =  2;  %
    %      n_max_sample_validation = 500;  %maximum number of samples for cross validation
    %      max_ite_CCCP_batch = 10;
    fold_k =  2;  %
    n_max_sample_validation = 500;  %maximum number of samples for cross validation
    max_ite_CCCP_batch = 50;
    n_repeat_test_set = 2;
    verbose = 1;
else
    fold_k = 5;%  2;  %
    n_max_sample_validation = 2000;   % 2000;  %maximum number of samples for cross validation
    max_ite_CCCP_batch = 50;
    n_repeat_test_set = 20; % number of repeating the algorithm  on different train set and test sets
    verbose =  0; % 0; % 1;
end



% parameters
% model prameters
classPrior = problemArg('classPrior');

lambda =  1.0;%0.005; %1;%0.05; %
kernelType ='rbf'; % 'linear';%
r1 =   1.0;
svm_theta_solver =  'CCCP_batch';%'double_hinge';% 'CCCP_online';% %%

 

% read data
data_str = 'E:\data_oil_spill\';
result_str = ['E:\result_oil_spill\result-' dataset '-' solver filesep ];

if strcmpi(dataset, 'data3')
    file_c = { ...
        'data3\sample10000_feature8',  'data3\sample60000_feature8';
        };
elseif strcmpi(dataset, 'data1')
    file_c = { ...
        'data1\data1_downsampling_9600_feature8',  'data1\data1_downsampling_240000_feature8';
        };
% else
%     file_c = { ...
%         'data3\sample10000_feature8',  'data3\sample60000_feature8';        
%         'data1\data1_downsampling_9600_feature8',  'data1\data1_downsampling_240000_feature8';
%         };
end


% file_c{i,1} is the data file used for training and testing, 
% file_c{i,2} is the data file  only used for testing and depicting the identification result


 
if strcmpi(dataset, 'data3')
    dataset_c     =  {'data3_sample10000'};
elseif strcmpi(dataset, 'data1')
    dataset_c     =  {'data1_sample9600'};
end
flag_scaling_v = [1  ];

%  dataset_c     =  {'sample10000_feature1','sample10000_feature2','sample10000_feature4',...
%                    'sample10000_feature8','sample10000_feature12','sample10000_feature16',...
%                    'sample10000_feature18','sample10000_feature19',...
%                    };
% flag_scaling_v = ones(1,8);


par_alg = ... % parameters for each dataset
    struct('classPrior',  classPrior , ...
    'lambda',     1.0,...
    'kernelType', 'rbf',... % 'linear';%
    'r1',   1.0,...
    'svm_theta_solver',  'CCCP_batch');

% parameters for cross validation
if flag_have_a_try
        mode_c = {   'p','pu'};
       par_search =struct(...
            'classPrior', [0.8],...
            'lambda',[   2^(-6)   ],...
            'r1',[ 2^2]);
    
    
%     mode_c = {   'pu'};
%              par_search =struct(...
%             'classPrior', [0.5],...
%             'lambda',[   2^(-1)   ],...
%             'r1',[ 2^2]);
    
%     mode_c = {   'p'};
%     par_search =struct(...
%         'classPrior', [ 0.5 0.8],...
%         'lambda',[ 2^(-1)  2^(-3)  ],... % 2^(-9)
%         'r1',[ 2^(-1)      2^2 ]);
    
%         mode_c = {   'p'};
%        par_search =struct(...
%             'classPrior', [0.8],...
%             'lambda',[   2^(-3)   ],...
%             'r1',[ 2^(-1)]);
%       classPrior_v = [ 0.6   0.9];
    
%     mode_c = {   'pu','normal'};
%      par_search =struct(...
%             'classPrior', [0.2  0.5   0.8  ],...
%             'lambda',[ 2^(-1)  2^(-3) 2^(-5) ],... % 2^(-9)
%             'r1',[ 2^(-2) 2^(-1)      2^2 ]);
    
     classPrior_v = [  0.4 ];
%     classPrior_v = [0.1 0.2 0.4 0.6 0.8 0.9];
 
    repeat_num_initial_point = 1;
    flag_putout_result_xls = 0;
    %flag_putout_result_xls = 1;
else
%     par_search =struct(...
%         'classPrior', [0.2 0.5 0.8],...
%         'lambda',[ 2^(-1)  2^(-3) 2^(-6)  ],... % 2^(-9)
%         'r1',[ 2^(-3)  2^(-1)      2^2   2^5 ]);
%      par_search = struct(...
%             'classPrior', [ 0.5 0.8],...
%             'lambda',[ 2^(-1)  2^(-3)  ],... % 2^(-9)
%             'r1',[ 2^(-1)  2    2^2 ]);    
     par_search =struct(...
            'classPrior', [0.2 0.5 0.8  0.99],...
            'lambda',[  2^(-1)  2^(-3)  2^(-5) ],... % 2^(-9)
            'r1',[ 2^(-2) 2^(-1)  2^0    2^2 ]);
    mode_c = {'normal', 'pu','pn',  'p'};
%     mode_c = {'normal'};
%     classPrior_v = [0.2];
    classPrior_v = [0.2 0.4 0.6 0.8 0.9];
    repeat_num_initial_point = 1; 
    flag_putout_result_xls = 1;
end


alg = @pu_predict;


for i_set=1:length(dataset_c )
    
    % % %     filename = [data_str file_c{ii,1}];
    datasetName = dataset_c{i_set};
    %%%existLibsvmTestFile = ~isempty(file_c{i_set,2});
    
    fprintf(1,'ii: %d\t dataset: %s\n',i_set,datasetName);
    matDataFile = sprintf('%s%s.mat',data_str,file_c{i_set,1});
    matDataFile_global = sprintf('%s%s.mat',data_str,file_c{i_set,2});
    trainFile_pu = sprintf('%s%s_train_%s_%s.mat',result_str,datasetName);
    xlsResultFile = sprintf('%s%s_result_%s_%s_%s.xls',result_str,datasetName,datestr(now,30));
    
    % 0.1 load data    
    if exist(matDataFile,'file') && exist(matDataFile_global,'file')
        data_s = load(matDataFile);
        %         X = data_s.data.input;
        %        y = data_s.data.output;
        X = data_s.X;
        y = data_s.Y;
        % load the global data
        data_global = load(matDataFile_global,'X','Y','n_row','n_col');
    else
        error('Mat data file %s or %s is not found.',matDataFile,matDataFile_global);
    end
    % check legality of the labels
    if nnz(y==1) + nnz(y==-1) < length(y)
        y_max = max(y);
        y_min = min(y);
        if nnz(y==y_max) + nnz(y==y_min) == length(y) && y_max > y_min
            warning('The labels consists of %d and %d and has been converted to -1 and 1.',y_min,y_max);
            y_old = y;
            y(y_old==y_max) = 1;
            y(y_old==y_min) = -1;
        else
            error('The labels should only consist of two values.');
        end
    end
    if verbose>0
        fwritef(1,'size_X',size(X), '%d\t');
    end
    %0.2 save the input data and output labels as a struct to  the data file
    data = struct('input', X, 'input_feature',[],'output',y );
    text = struct();
    if ~exist(matDataFile,'file')
        save(matDataFile,'data','text');
    else
        variableInfo = who('-file', matDataFile);
        if ~ismember('data', variableInfo) ||  ~ismember('text', variableInfo)
            save(matDataFile,'data','text','-append');
        end
    end    
    
    trainFile_c =cell(1,n_repeat_test_set);
    testFile_c =cell(1,n_repeat_test_set);
    for i_repeat_split = 1: n_repeat_test_set
        % 1. split train set/test set     
            [trainFile_c{i_repeat_split },testFile_c{i_repeat_split}] = foapl_split(matDataFile,'flag_standardize',flag_scaling_v(i_set),...
                'train_test_rate',train_test_rate );
    end
    
    n_prior = length(classPrior_v);
     %acc_s = cell(n_prior,n_repeat_test_set);
     %num_s = cell(n_prior,n_repeat_test_set);
     time_v= zeros(n_prior,n_repeat_test_set);
     
     
    for i_mode = 1:length(mode_c)
        mode = mode_c{i_mode};
        matResultFile =  sprintf('%s%s_result_%s_%s.mat',result_str,datasetName,mode,datestr(date));
        matDataFile_global_standarize = sprintf('%s%s_data_global_%s_%s.mat',result_str,datasetName,mode,datestr(date));
        fwritef(1,'mode',mode,'');
        for i_prior = 1:length(classPrior_v)
            classPrior = classPrior_v(i_prior);
            fwritef(1,'prior',classPrior,'');
            
            trainFile_pu = sprintf('%s%s_train_%s_%s.mat',result_str,datasetName,mode,num2str(classPrior));
            matScoreFile =  sprintf('%s%s_score_%s_%s.mat',result_str,datasetName,mode,num2str(classPrior));
            for i_repeat_split = 1: n_repeat_test_set
                
                
                trainFile = trainFile_c{i_repeat_split};
                testFile = testFile_c{i_repeat_split};
                
                % 2.0  get X_train, y_train
                    data_train = load(trainFile,'X','y','ind','mean_v','std_v');
                    X_train = data_train.X;
                    y_train = data_train.y;
                    %         X_train = data_train.data.input;
                    %         y_train = data_train.data.output;
                    ind_train = data_train.ind;                 
                
                % 2.1 generate labels of PU-learning instances and save train data
                [y_pu, ii_train] =  pu_label(y_train,classPrior,mode);
                y_observed = y_pu;
                if strcmpi(solver,'CCCP')
                    if strcmpi(mode,'pn')
                        y_pu(y_pu==0) = 1; % all the missing labels are marked +1
                    else % mode == 'p'
                        y_pu(y_pu==0) = -1;
                    end
                elseif strcmpi(solver,'svm')
                    if strcmpi(mode,'pn') || strcmpi(mode,'p')
                        ii_train(y_pu==0) = []; % all the missing labels are not used for training
                        y_pu(y_pu==0) = [];
                                    % in mode 'p', there would be only one class of label
                                    %   one-class classification would be operated                       
                    end
                end
                    
                if strcmpi(mode,'pn')
                    saveData(trainFile_pu,'X',X_train(ii_train,:),'y',y_pu,'y_observed',y_observed,...
                        'sizeX',size(X_train),'ind', ind_train(ii_train), 'X_feature',{});
                else % mode == 'p', 'pu'
                    saveData(trainFile_pu,'X',X_train(ii_train,:),'y',y_pu, ...
                        'sizeX',size(X_train),'ind', ind_train(ii_train), 'X_feature',{});
                end
                if verbose>0
                    fwritef(1,'n_pos_pu',nnz(y_pu==1),'',  'n_unlabel_pu',nnz(y_pu==-1),'');
                end
                
                % 2.2. cross validation
                par_opt_s = struct();
                if i_repeat_split == 1 % operate  cross-validation  only once for each mode and each i_prior
                    if strcmpi(solver,'CCCP')
                    [result_opt,par_opt]= crossValidate(alg,trainFile_pu, par_alg, par_search,...
                        'k',fold_k,'n',n_max_sample_validation,'bestResult',@findBestResult,'labelMode',mode);
                    fwritef(1, 'par_opt',par_opt,'');
                    par_opt_s(i_prior) = par_opt;
                    elseif strcmpi(solver,'svm') % svm
                        tic
                        SVMModel = fitcsvm(X_train(ii_train,:),y_pu,'Standardize',false,'KernelFunction','RBF','KernelScale','auto');
                            % do not standardize, since we have standardized the feature values manually                    
                        t = toc;                         
                    end
                end
                % 2.3. train the model with the searched optimal parameter
                if strcmpi(solver,'CCCP')
                    tic
                    userSetting({'repeat_num_initial_point',repeat_num_initial_point});
                    foapl_solve('-lambda',par_opt.lambda,'-r',par_opt.r1,'-pi',par_opt.classPrior,...
                        '-v',verbose, trainFile_pu,testFile, matScoreFile);
                    userSetting([]);
                    t = toc;
                elseif strcmpi(solver,'svm') % svm
                    data_test = load(testFile,'X','y','ind','mean_v','std_v');
                     [label,score_test] = predict( SVMModel ,data_test.X);
                     if size(score_test,2)>1
                         score_test = score_test(:,2);
                     end
                     saveData(matScoreFile,'score_test',score_test);
                end % for svm do not need to re-train the model again
                
                % 2.4. accuracies on test set
                [acc,num]= foapl_accuracy(matScoreFile,testFile);    % test accuracy
                acc_s(i_prior,i_repeat_split) = acc;
                num_s(i_prior,i_repeat_split) = num;
                time_v(i_prior,i_repeat_split) = t;
                save(matResultFile,'acc_s','num_s','matScoreFile','testFile','solver','trainFile_pu','par_opt_s','mode','fold_k','n_max_sample_validation');
                
                % 2.5 draw the identification results on the global area
                if  i_repeat_split == 1 
                    % 2.5.0 standarize the global input data
                    [X_global] = standardize(data_global.X, data_train.mean_v, data_train.std_v);
                    % 2.5.1 save the global data to file
                    saveData(matDataFile_global_standarize,'X',X_global,'y',data_global.Y,...
                        'sizeX',size(X_global),'ind', [], 'X_feature',{});
                    % 2.5.2 predict the label of the global data
                    if strcmpi(solver,'CCCP')
                        train_s = load(matScoreFile,'model','weight');
                        [score_global]= foapl_test(train_s.model,trainFile_pu,matDataFile_global_standarize,train_s.weight.w);
                    elseif  strcmpi(solver,'svm')
                        score_global = predict( SVMModel , X_global);
                    end
                    
                    Y_global_predict =  reshape(1.0*(score_global>=0),data_global.n_row,data_global.n_col);
                    
                    imageFileName = [ 'predictGlobal_' datasetName '_' mode '_' num2str(classPrior)];
                    %imagesc(Y_global_predict);                    
%                    imageFileName = [result_str 'predictGlobal_' dataset '_' mode '_' num2str(classPrior)];
%                     box off
%                     saveas( gcf,[imageFileName '.png']);
%                     saveas( gcf,[imageFileName '.fig']);
                    parImage.path = result_str;  
                    plot_feature_image(Y_global_predict,imageFileName,parImage);
                    
                end
                %%%
                % % %             foapl_solve('-lambda',par_opt.lambda,'-r',par_opt.r1,'-pi',par_opt.classPrior,...
                % % %                 trainFile_pu,testFile, matScoreFile);
                % % %             [acc2,num2]= foapl_accuracy(matScoreFile,testFile);    % test accuracy
                % % %             foapl_solve('-lambda',par_opt.lambda,'-r',par_opt.r1,'-pi',par_opt.classPrior,...
                % % %                 trainFile_pu,testFile, matScoreFile);
                % % %             [acc3,num3]= foapl_accuracy(matScoreFile,testFile);    % test accuracy
                %%%%%
            end % end the loop of i_repeat_split
            
          
            
        end % end the loop of i_classPrior
        
        
        % 3.0 calculate average accuracy and elapsed time
        for i_prior = 1:length(classPrior_v)            
            acc_mean_table =   varfun(@mean,struct2table(acc_s(i_prior,:)));
            acc_std_table =   varfun(@std,struct2table(acc_s(i_prior,:)));
            acc_mean(i_prior) = table2struct(acc_mean_table);
            acc_std(i_prior) = table2struct(acc_std_table);
            
            num_mean_table =   varfun(@mean,struct2table(num_s(i_prior,:)));
            num_std_table =   varfun(@std,struct2table(num_s(i_prior,:)));
            num_mean(i_prior) = table2struct(num_mean_table);
            num_std(i_prior) = table2struct(num_std_table);
        end
        time_mean = mean(time_v,2); 
        
        %  3.1 put out results to xls file ============
        if flag_putout_result_xls
            par0.timeStampe = datestr(now,30);
            par0.dataset = datasetName;
            par0.mode = mode;
            par0.classPrior= classPrior;
            par0.matScoreFile= matScoreFile;
            par0.testFile=  testFile;
            par0.trainFile_pu= trainFile_pu; % file names
            par0.fold_k= fold_k;
            par0.n_max_sample_validation=  n_max_sample_validation;
            par0.train_test_rate= train_test_rate;
            par0.classPrior_v= classPrior_v;  % parameters
            
            % calculate the first cell, e.g., 'A1', 'A5', 'A7',...
            C = num2cell((0:7)*(length(classPrior_v)+2)+1);
            %C = cellfun(@(x)['A' num2str(x)],C, 'unformOutput',false);
            for ii=1:length(C)
                C{ii} = ['A' num2str(C{ii})];
            end
            
            fwritexls(xlsResultFile,  '',par0,C{1},mode, ...
                'parameters',par_opt_s, C{2},mode,...
                '',num_mean,C{3},mode,...
                '',num_std,C{4},mode,...
                '',acc_mean, C{5},mode,...
                '',acc_std, C{6},mode,...
                'tims (s)',time_mean,C{7},mode,... % results
                'hhhhhhh');
        end
        
        fwritef(1,'num_s',num_s,'');
        
        
    end % end the loop of mode
    
    % remove train and test file
end

userSetting([]);

