% main_crossValidate_oil

% cross validation for select the proper number of features

 clear 
 clc
 
 
flag_classical_classification  =  1; %0; % classical binary classification 
flag_scaling = 1; % whether do scaling to make each feature values zero-mean and unit variance
flag_have_a_try = 0;  % 1 or 0, whether just have a try to see whether the code run well
 
if flag_have_a_try
    fold_k =  2;  %
    n_max_sample_validation = 500;  %maximum number of samples for cross validation
    max_ite_CCCP_batch = 10; 
    verbose = 1;
else
    fold_k = 3;%  2;  %
    n_max_sample_validation = 1000;  %maximum number of samples for cross validation
    max_ite_CCCP_batch = 10;
    verbose =  0; % 1;    
end



% parameters
  % model prameters
classPrior = problemArg('classPrior');

lambda =  1.0;%0.005; %1;%0.05; %
kernelType ='rbf'; % 'linear';%
r1 =   1.0;
svm_theta_solver =  'CCCP_batch';%'double_hinge';% 'CCCP_online';% %% 

% % %   userSetting({'verbose',verbose,'max_ite_CCCP_batch',max_ite_CCCP_batch});

 
% read data
%data_str = 'E:\data_oil_spill\data3\';
data_str = 'E:\data_oil_spill\data1\';
result_str = 'E:\result_oil_spill\';

 

% file_c = { ...
%      'sample10000_feature1',                '';    
%      'sample10000_feature2',                ''; 
%      'sample10000_feature4',                ''; 
%      'sample10000_feature8',                ''; 
%      'sample10000_feature12',                ''; 
%      'sample10000_feature16',                ''; 
%      'sample10000_feature18',                ''; 
%      'sample10000_feature19',                ''; 
%     };  

file_c = { ...
     'data1_downsampling_feature1',                '';    
     'data1_downsampling_feature2',                ''; 
     'data1_downsampling_feature4',                ''; 
     'data1_downsampling_feature8',                ''; 
     'data1_downsampling_feature12',                ''; 
     'data1_downsampling_feature16',                ''; 
     'data1_downsampling_feature18',                ''; 
     'data1_downsampling_feature19',                ''; 
    }; 

 
% % %  dataset_c     =  {'sample10000_feature1','sample10000_feature2','sample10000_feature4',...
% % %                    'sample10000_feature8','sample10000_feature12','sample10000_feature16',...
% % %                    'sample10000_feature18','sample10000_feature19',...
% % %                    };
dataset_c = file_c(:,1);
flag_scaling_v = ones(1,8);



par_alg = ... % parameters for each dataset
    struct('classPrior',  classPrior , ...           
           'lambda',     1.0,...
           'kernelType', 'rbf',... % 'linear';%
            'r1',   1.0,...
            'svm_theta_solver',  'CCCP_batch'); 
        
% parameters for cross validation        
if flag_have_a_try   
     par_search =struct(...
     'classPrior', [0.9],...    
     'lambda',[   2^(-9)   ],...
     'r1',[ 2^6 2^9 ]);
else
    par_search =struct(...    
     'classPrior', [0.2 0.5 0.8],... 
     'lambda',[   2^(-3) 2^(-6) 2^(-9)  ],...
     'r1',[ 2^(-3)  2^(-1)      2^2   2^5 ]);
     %'r1',[2^(-2) 1  2^1  2^2  2^3  2^4  2^6   2^9  2^15]);
end

 
 alg = @pu_predict;
 
 

for ii=1 :length(dataset_c )
    
% % %     filename = [data_str file_c{ii,1}];
    dataset = dataset_c{ii};
    existLibsvmTestFile = ~isempty(file_c{ii,2});
    fprintf(1,'ii: %d\t dataset: %s\n',ii,dataset);
    matDataFile = sprintf('%s%s.mat',data_str,dataset);
    trainFile = sprintf('%s%s_train.mat',result_str,dataset);
 
    % load data
% % %     [y, X] = libsvmread( filename );
    if exist(matDataFile,'file')
        data_s = load(matDataFile);
%         X = data_s.data.input; 
 %        y = data_s.data.output; 
         X = data_s.X; 
         y = data_s.Y;
    else
        error('Mat data file %s is not found.',matDataFile);
    end
    
    if nnz(y==1) + nnz(y==-1) < length(y)
         y_max = max(y);
        y_min = min(y);     
       
        if nnz(y==y_max) + nnz(y==y_min) == length(y) && y_max > y_min
            warning('The labels consists of %d and %d and has been converted to -1 and 1.',y_min,y_max);
            y_old = y;
            y(y_old==y_max) = 1;
            y(y_old==y_min) = -1;
        else
            error('The labels should only consist of two values.');
        end
    end
    
    if verbose>0
        fwritef(1,'size_X',size(X), '%d\t');
    end
    
    
    if ~existLibsvmTestFile
        % save the data to matDataFile
        data = struct('input', X, 'input_feature',[],'output',y );
        text = struct();
        if ~exist(matDataFile,'file')
            save(matDataFile,'data','text');
        else
            save(matDataFile,'data','text','-append');
        end
        % split the train and test file
        [trainFile,~] = foapl_split(matDataFile);
    end
    
    %  get X_train, y_train
    if existLibsvmTestFile
        X_train = X;
        y_train = y;
        ind_train = 1:size(X,1);
        if flag_scaling_v(ii) 
        [X_train, mean_v,std_v] = standardize(X_train); % make each column of X zero-mean and unit variance
        end
    else % do not exist/use libsvm test file
        data_train = load(trainFile,'X','y','ind');
        X_train = data_train.X;
        y_train = data_train.y;
        ind_train = data_train.ind;
    end
    
    % generate labels of PU-learning instances and save train data
    if ~flag_classical_classification
        [y_pu, ii_train] =  pu_label(y_train,classPrior);
    else % classical classification
        y_pu = y_train;
        ii_train = 1:length(y_train);
    end
    saveData(trainFile,'X',X_train(ii_train,:),'y',y_pu,...
        'sizeX',size(X_train),'ind', ind_train(ii_train), 'X_feature',{});
    if verbose>0
        fwritef(1,'n_pos_pu',nnz(y_pu==1),'',  'n_unlabel_pu',nnz(y_pu==-1),'');
    end
    
    
  [result_opt,par_opt]= crossValidate(alg,trainFile, par_alg, par_search,...
      'k',fold_k,'n',n_max_sample_validation,'bestResult',@findBestResult);
  
    
% % % [acc_opt,par_opt]= foapl_crossValidate(trainFile, fold_k,para_crossVal{:});

fwritef(1, 'par_opt',par_opt,'');
    
end

