function plot_feature_image(X,varName,arg)
% Input:
%   X: a n-by-m-by-d matrix, with
%       n: the number of rows;
%       m: the number of columns;
%       d: the number of features;
%   varName: name of the matrix X, used to name the output images
%   arg: an optional struct indicating the parameters, including the following fields
%     .path:  path to save the image files, if the specified not exist,
%        the function would make the folder, default value: the current path;
%     .actRow: a vector of indices indicating the selected rows, default value: 1:n
%     .actCol: a vector of indices indicating the selected columns, default value: 1:m
%     .actFeature: a vector of indices indicating the selected features, default value: 1:d
%  operation:
%    plot the feature images and  save the images in the specified path

% set defualt values of the parameters
[n_row,n_col,n_feature] = size(X); % number of features
arg = completeArg(arg, ...
    {'path', 'actRow', 'actCol','actFeature'},...
    { pwd,   1:n_row,   1:n_col, 1:n_feature });
arg.path = addFileSep(arg.path);



% standarization of X
n_actRow = length(arg.actRow);
n_actCol = length(arg.actCol);
n_actFeature = length(arg.actFeature);

X_standardize = zeros(n_actRow,n_actCol,n_actFeature);
for ii=1:n_actFeature
    i_feature=arg.actFeature(ii);
    X_standardize(:,:,ii) = reshape(standardize(columnVec(X(arg.actRow,arg.actCol,i_feature))),n_actRow,n_actCol);
end
% make dir of the feature images
dataPathFeatureImage = arg.path;
if ~exist(dataPathFeatureImage,'dir')
    status = mkdir(dataPathFeatureImage);
    if status
        fprintf(1,'succeed to make folder %s\n ',dataPathFeatureImage);
    else
        error(1,'Failed to make folder %s\n ',dataPathFeatureImage);
    end
end
% save featrue images
for i_feature=1:n_actFeature
    fileName = [dataPathFeatureImage varName '_' num2str(i_feature)];
    % plot colored feature images
    imagesc(X_standardize(:,:,i_feature));
    colormap('parula');
    caxis([-2 2]);
    box off
    axis off
    pbaspect([1,2,1])
    
    
    set(gcf, 'PaperPosition', [0 0 2.5 5]); %Position plot at left hand corner with width 2.5 and height 5.
    set(gcf, 'PaperSize', [2.5 5]); %Set the paper to have width 2.5 and height 5.
    
    
    saveas(gcf,[fileName '.png']);
    saveas(gcf,[fileName '.fig']);
    % plot gray feature images
    imagesc(X_standardize(:,:,i_feature));
    colormap('gray');
    caxis([-2 2]);
    box off
    axis off
    pbaspect([1,2,1]);
    
    set(gcf, 'PaperPosition', [0 0 2.5 5]); %Position plot at left hand corner with width 2.5 and height 5.
    set(gcf, 'PaperSize', [2.5 5]); %Set the paper to have width 2.5 and height 5.
    
    saveas(gcf,[fileName '_gray.png']);
    saveas(gcf,[fileName '_gray.fig']);
end

end