function produceSampleData(matDataFile,parDownSampling,arg)
% produce sample data 
%  matDataFile:  matDataFile consisting of X and Y with X m-by-n-by-d matrix, Y m-by-n matrix
%  parDownSampling: struct for down sampling, set [] if do not operate down sampling
%   .size, a vector of 2 positive integer, indicating the down sampling size,   e.g. [80 125];
%       set parDownSampling.size = [] to select all the selected rows and columns
%   .actRow, a vector of selected row indices, set [] to select all the rows 
%   .actColumn, a vector of selected column indices, set [] to select all the columns
%  arg: struct of optional  parameters
%   .actFeature:  a vector of selected feature indices or a cell array of a series of selected
%       features, e.g.,  [1 3 6 7] or {[1 8], [2 3 6 7 ]}; 
%       default value  []
%   .saveImage: 1 or 0, whether to put out the feature images, default 1;
% versions
%  1st version. 2019.1.22

% 0. complete parameter arg
arg = completeArg(arg,{'actFeature','saveImage'},{[],1});

% 1. load the data
data_s = load(matDataFile, 'X','Y');
X_input = data_s.X;
Y_input = data_s.Y;   
[nRow,nCol,nDim] = size(X_input);

[dataPath,dataFileName] = fileparts(matDataFile);
dataPath = addFileSep(dataPath);

% 2. down-sampling
par = parDownSampling;
flag_resampling = ~isempty(par);

if flag_resampling
    par = completeArg(par, {'size', 'actRow', 'actColumn'},{[],[],[]});   
    if isempty(par.actRow)
        par.actRow = 1:nRow;
    end    
    if isempty(par.actColumn)
        par.actColumn = 1:nCol;
    end     
    X_input_act = X_input(par.actRow,par.actColumn,:);    
    Y_input_act = Y_input(par.actRow,par.actColumn);    
    
    n_sample = prod(par.size);
    outputFile_mat = [dataPath,dataFileName,'_sample_' num2str(n_sample) '.mat' ];
    
    [X,Y,ind_row,ind_col] = figure_sampling(X_input_act,Y_input_act,par);
    [n_row,n_col] = size(Y);
    save(outputFile_mat, 'X','Y','n_row','n_col');    
else
    X = X_input;
    Y = Y_input;
end

% 3. save feature images 
 
if arg.saveImage    
    parImage.path = [addFileSep(dataPath) 'featureImage']; % path to save feature images
    % save featrue images    
    plot_feature_image(X,'X',parImage);
    % save the colored label  image
    plot_feature_image(Y,'Y',parImage);
    fprintf('finished to save images.\n');
end

% 4. generate standard sample data with specified features

if ~isempty(arg.actFeature)    
   % reshape     
    [n_row,n_col] = size(Y);
    n_sample = n_row*n_col;
    X = reshape(X,n_sample,nDim);
    Y = reshape(Y,n_sample,1);
   if  isnumeric(arg.actFeature)  
       arg.actFeature = {arg.actFeature};
   end
       
    % select certain number of features 
    for ii = 1:length(arg.actFeature)
        actFeature = arg.actFeature{ii}; 
        numFeature = length(actFeature);
        fileName = [dataPath   dataFileName '_' num2str(n_sample) '_feature' num2str(numFeature) '.mat'];
        saveData(fileName,'X',X(:,actFeature),'Y',Y,...
           'n_row',n_row,'n_col',n_col); % save X and Y with selected feature values
    end
    fprintf('finished to produce standard sample data file with specified features.\n');
end
    
end