function [X_output,Y_output,ind_row,ind_col] = figure_sampling(X,Y,arg)
% produce samples from given figures
% Inputs:
%   X: a nRow-by-nColumn-by-nFeature array, with nRow the nubmer of rows, nColumn the number
%   of columns, nFeature the number of features,
%   Y: a nRow-by-nColumn  matrix, consisting of ones and zeros (or 1s and -1s)
%       indicating the class of each pixel 
%   arg: parameters
%    	.mode:
%           'rand': optional, select certain  samples of certain rows and colcumns in random 
%           'downsampling': down sampling, default value 'rand'
%       .size: a vector of 2-by-1:
%           indicating the size of the output features  and labels, y_output
% Outputs:
%   X_output: a m-by-n-by-nFeature array, with [m,n]=arg.size, nFeature = size(X,3) the number of features
%   Y_output: a m-by-n matrix consisting of 1  and -1 
%   ind_row, ind_col: indices of selected rows and columns 

 nRow_select =  arg.size(1);
 nCol_select =  arg.size(2);
nRow = size(X,1);
nCol = size(X,2);
 

X_output = [];
Y_output = [];
ind_row = [];
ind_col = [];
% check the size of X and Y
if nRow~=size(Y,1) || nCol~=size(Y,2)
    error('The input X and Y array should have the same number of rows and columns');
end


% check the elements of Y
if  nnz(Y==1) + nnz(Y==0) < numel(Y)   &&   nnz(Y==1) + nnz(Y==-1) < numel(Y)
    error('The matrix of labels should consists of ones and zeros or (ones and negative ones)');
end
if nRow_select > nRow || nCol_select > nCol
    error('The number of selected rows and columns should less than the number of Rows and columns of X, resp.');
end
if nRow_select <=0 || nCol_select<=0
    return
end



if ~isfield(arg,'mode') || isempty(arg.mode)
    arg.mode = 'downsampling';
end


if strcmpi(arg.mode,'rand')
    ind_row = randperm(nRow,nRow_select);
    ind_col = randperm(nCol,nCol_select);
else % down sampling
    if nRow_select ==1
        ind_row = 1;
    else
        sep_row  = ceil( (nRow-1)/(nRow_select-1) );
        ind_row =  1:sep_row:nRow;
        % fill extra number of rows
        len_ind_row = length(ind_row);
        if len_ind_row < nRow_select
            ind_row2  = 2:sep_row:nRow;
            ind_row = [ind_row ind_row2(1:nRow_select-len_ind_row)];
            ind_row = sort(ind_row);
        end
    end
    
    
    if nCol_select  == 1
        ind_col = 1;
    else
        sep_col =  ceil( (nCol-1)/(nCol_select-1)); %   sep_col >=2
        ind_col = 1:sep_col:nCol;
        % fill extra number of columns
        len_ind_col = length(ind_col);
        if len_ind_col < nCol_select
            ind_col2  = 2:sep_col:nCol;
            ind_col = [ind_col ind_col2(1:nCol_select-len_ind_col)];  % len_ind_col <= nCol_select
            ind_col = sort(ind_col);
        end
    end   
    
end

X_output = double(X(ind_row,ind_col,:));
Y_output = double(Y(ind_row,ind_col));

Y_output(Y_output==0) = -1;  