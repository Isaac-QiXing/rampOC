function [model,score_train,varargout]= foapl_train(trainFile,varargin)
% train the C-Ranker model
% Inputs:
%  trainFile: mat file name containing the data for training
%  varargin: the names and values of arguments of for training the C-Ranker
%           model;
%    varargin{2*i-1}: a string, the argument name;
%    varargin{2*i}: the argument value of varargin{2*i-1}; for i=1, 2, ...
%    the optional arguments are as follows: 
%       'lambda'
%    	'r1' 
%       'classPrior'
%    	'verbose'
%   	'svm_theta_solver'
%       'mu_pos': parameter of clean operation of FoApL algorithm
%       'mu_neg': parameter of clean operation of FoApL algorithm
% Outputs:
%  model: a structure (array) indicating the trained C-Ranker model(s);
%  score_train: a column vector (or a matrix) consisting of the scores of
%     PSMs in train set; 
%  varargout{1}: a structure indicating the calculated feature weights;
%       It contains the following fields:
%        .w : a column vector indicating the feature weights;
%        .std: a column vector indicating the standard variance of each
%           feature weight observed by the submodels; it is set [], if
%           'flag_w' is  set 'manual';
%   varargout{2}: a struct of the iteration charateristics in training the model

 

% assign the arguments to a structure
% % % [kernelType,c1,c2,return_submodel,maxTrainSize,num_submodel,...
% % %     num_submodel_preliminary,lb_reliable_score,weight_xcorr,flag_w,verbose,svm_theta_solver,...
% % %      c3,lambda,r1,tol_violating_pair_initial,tol_violating_pair_min,mu_neg,mu_pos,...
% % %    	n_initial_cardinality_S,fix_train_order,tolFun_foapl] = ...
% % %     problemArg('kernelType','c1','c2','return_submodel','maxTrainSize','num_submodel',...
% % %       'num_submodel_preliminary', 'lb_reliable_score','weight_xcorr','flag_w','verbose','svm_theta_solver',...
% % %       'c3','lambda','r1','tol_violating_pair_initial','tol_violating_pair_min','mu_neg','mu_pos',...
% % %    	'n_initial_cardinality_S',	'fix_train_order','tolFun_foapl');

[ svm_theta_solver,kernelType,r1,classPrior,lambda,verbose,mu_pos,mu_neg] =   ...
    problemArg( 'svm_theta_solver', 'kernelType','r1','classPrior','lambda','verbose',...
     'mu_pos','mu_neg');

% 0.1 get arguments
% [par_new,varargin_par ] = identifyPar(varargin{:});
% arg = struct();
% len_arg = length(par_new); 
% if len_arg>0
%     arg = assignStruct('', par_new(1:2:len_arg),par_new(2:2:len_arg));
% end


arg = [];
len_arg = length(varargin); 
if len_arg>0
    arg = assignStruct('', varargin(1:2:len_arg),varargin(2:2:len_arg));
end

arg = completeArg(arg, ...
    {'classPrior',  'lambda',   'svm_theta_solver',  'kernelType','r1','mu_pos','mu_neg' },...
	{classPrior,    lambda,      svm_theta_solver,    kernelType, r1,   mu_pos,  mu_neg});

% % % arg = completeArg(arg, ...
% % %     {'flag_w','c1','c2','return_submodel','maxTrainSize',...
% % %      'num_submodel','kernelType','r1','weight_xcorr'...
% % %      'c3','lambda', 'svm_theta_solver','verbose',...
% % %    	'tol_violating_pair_initial','tol_violating_pair_min','mu_neg','mu_pos',...
% % %    	'n_initial_cardinality_S',	'fix_train_order','tolFun_foapl'  },...
% % % 	{flag_w,c1, c2, return_submodel, maxTrainSize,...
% % %       num_submodel, kernelType,r1,weight_xcorr,...
% % %        c3,lambda,svm_theta_solver,verbose,...
% % %    	tol_violating_pair_initial,tol_violating_pair_min,mu_neg,mu_pos,...
% % %    	n_initial_cardinality_S,fix_train_order,tolFun_foapl});

% ===   calculate cp and cu ===
data_s = load(trainFile,'y');
np_total = nnz(data_s.y ==1);  % np:number of positive instances
nu_total = nnz(data_s.y == -1); % np:number of unlabeled instances; all the unlabeled instances are labled -1
np_toal = max(np_total,1);
nu_total = max(nu_total,1) ;
if strcmpi(arg.svm_theta_solver,'CCCP_batch')
    np = np_total;
    nu = nu_total;
    cp = 2* arg.classPrior/(np*arg.lambda);
    cu = 1/(nu*arg.lambda);
else %strcmpi(svm_theta_solver,'CCCP_online')
    %for the online algorithm arg.cp and arg.cu are the INITIAL weights for the loss of positives
    %   and unlabeled instances
    gamma = np_toal/(np_toal+nu_total);
    cp = 2* arg.classPrior/(gamma*arg.lambda);
    cu = 1/((1-gamma)*arg.lambda);
end

arg = completeArg(arg, ...
    { 'cp','cu' },...
	{cp,    cu });

  
% % % % get feature weights: arg.w
% % % load(trainFile,'X_feature');
% % % arg.w = get_feature_weight(X_feature,arg);  % arg.w <-- X_feature, arg.weight_xcorr
arg.w = [];
  
argTrain = struct('dataFile',trainFile);     
argScore = struct('trainFile',trainFile,'kernelType',arg.kernelType,...
    'r1',arg.r1,'w',arg.w,'flagOutput','train');     

weight = struct('w',[],'std',[]);           
% % % num_submodel_origin = arg.num_submodel;
% % % flag_w_auto = strcmpi(arg.flag_w,'auto'); % whether flag_w is 'auto' format
% % % if flag_w_auto
% % %     % solve the feature weights adaptively
% % %     % (1) train a preliminary model
% % %     if verbose>=1
% % %         fprintf(1,'Step 1: training a preliminary model...\n');
% % %     end 
% % %     arg.num_submodel = num_submodel_preliminary; % reset argument num_submodel
% % %     %%%model = targetRank_theta_repeat(argTrain,arg);    
% % %     model = targetRank_CCCP(argTrain,arg);
% % %     % (2) solve the feature weights    
% % %     if verbose>=1
% % %         fprintf(1,'Step 2: adjusting the feature weights...\n');
% % %     end
% % %        % calculate the score
% % %     [score_train ] = calulate_score(model,argScore);
% % %     load(trainFile,'X','y');
% % %     ind_rel = (y==-1 | y==1 & (score_train >= lb_reliable_score));               
% % %         % solve the feature weights (the arguments using default values)    
% % %     [weight.w,weight.std] = ...
% % %         foapl_feature_weight('','X',X(ind_rel,:),'y',y(ind_rel));    
% % %     arg.w = weight.w; % assign the calculated weights to arg.w
% % %     
% % %     if verbose>=3
% % %         fprintf(1,'Finished to detemine the feature weights.');
% % %         fwritef(1,'feature weights',(weight.w)','',...
% % %             'standard deviation', (weight.std)','');
% % %     end   
% % % else 
% % %     weight.w = arg.w; % update weight.w for putout
% % % end

weight.w = arg.w; % update weight.w for putout

% assign the put out
if nargout>2
    varargout{1} = weight;
end
  
% train the model formally
if verbose>=2
%     if flag_w_auto
%         fprintf(1,'Step 3: solving the model formally...\n');
%     else
        fprintf(1,'Solving the reliable PSMs...\n');
%     end
end

% % % arg.num_submodel = num_submodel_origin; % recover the argument num_submodel
%%%model = targetRank_theta_repeat(argTrain,arg);

 


ite_inf = struct(); 
if strcmpi(arg.svm_theta_solver,'CCCP_online') || strcmpi(arg.svm_theta_solver,'CCCP_batch') ...
        || strcmpi(arg.svm_theta_solver,'double_hinge')
    [model,ite_inf] = targetRank_CCCP(argTrain,arg); 
else
% % %     model = targetRank_theta_repeat(argTrain,arg);
    error('Only support ''CCCP_online'' and ''CCCP_batch'' solver in current algorithm.');
end
 
if nargout>=4
    varargout{2} = ite_inf;
end

% calculate the score
argScore.w = arg.w; 
if arg.return_submodel
    argScore.flagOutput = 'train+';
else
    argScore.flagOutput = 'train';
end
score_train = calulate_score(model,argScore);

if verbose>=2
   fprintf(1,'Finished to solve the reliable targets.\n');
end

end
