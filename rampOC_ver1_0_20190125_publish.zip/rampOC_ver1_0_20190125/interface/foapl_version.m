function foapl_version(varargin)
% get the C-Ranker version
% Inputs:
%  arg: '': return the version;
%       '-date': return the release date of the C-Ranker software

ver = '1.0';
if nargin>0
    % print the publication date 
	arg = varargin{1};
    if strcmpi(arg,'-date')
        ver = 'Jan 25, 2019';        
    end
end
fprintf(1,'%s\n',ver);

end
