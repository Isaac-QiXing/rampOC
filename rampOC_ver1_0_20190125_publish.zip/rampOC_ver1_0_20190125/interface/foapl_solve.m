function foapl_solve(varargin)
% train a PU classifier, calculate scores of training instances and test instances (if exist) 
% Inputs:
%    varargin{2*i-1}: a string, the parameter name;
%    varargin{2*i}: the parameter value of varargin{2*i-1}; for i=1, 2, ...
%    the optional arguments are as follows:
%       '-g': value: 1 or 0, whether to standardize data (make each column
%             zero-mean and unit-variance), default 0;
%       '-f': 0, 1 or 2: whether split the samples into train set and test set;
%             0: do not split the samples into train set and test set;
%             1: split the samples into train set and test set;
%             2: employ the user-supplied training set and test set;   
%       '-t': a positive scalar indicating the rate of cardinality of train
%          set  to the cardinality of test set; effective if '-f' is set 1;
%       '-r': a positive scalar, the kernel parameter;
%       '-lambda': regularization parameter 
%       '-s': solver 
%       '-pi': class prior of positive instances
%       '-mupos': parameter of clean operation of FoApL algorithm
%       '-muneg': parameter of clean operation of FoApL algorithm
%       '-v':  0,  2 or 3
%        0: do not print any information to command window;       
%        2: put out progress information briefly to command window;
%        3: put out detailed progress information to command window;
%  
%   The last  three  inputs: train file, test file and score file names
%
% usage 1.
%       foapl_solve(matTrainFile,matTestFile,matScoreFile)
%
%   matScoreFile: name of file  (with extension .mat) which contains the calculated
%       scores and trained model;
%
%   matTrainFile, and matTestFile: name of file (with extension .mat) which
%       consists of the training samples and test samples, refer to the
%       outputs of foapl_split() for details of the variables therein     
%   
% usage 2. set  parameters
%       foapl_solve('-lambda','0.125','-r','1', matTrainFile,matTestFile,matScoreFile)
%
% Operations:
%    the function put out iteration information at the training process to
%    matScoreFile
  

% 0.1 get arguments
[par_new,varargin_par ] = identifyPar(varargin{:});

arg = struct();
len_arg = length(par_new); 
if len_arg>0
    arg = assignStruct('', par_new(1:2:len_arg),par_new(2:2:len_arg));
end

% get  matDataFile, matScoreFile and matIteFile
if length(varargin_par)<2
    error('There should be at least two inputs variables:  matDataFile and matScoreFile.');
elseif length(varargin_par)==2
    matDataFile = varargin_par{1};
    matScoreFile = varargin_par{2};     
elseif length(varargin_par)==3
    trainFile = varargin_par{1};
    testFile = varargin_par{2};
    matScoreFile = varargin_par{3};
else
    error('There should be two or three input file names.');
end


[flag_split_train_test,train_test_rate,flag_standardize, path_foapl_data,verbose,lambda,...
    svm_theta_solver,mu_pos,mu_neg,classPrior,r1] = ...
    problemArg('flag_split_train_test','train_test_rate','flag_standardize','path_foapl_data',...
    'verbose','lambda','svm_theta_solver','mu_pos','mu_neg','classPrior','r1');

arg = completeArg(arg, ...
  {'train_test_rate','flag_w','weight_xcorr','c1','c2','return_submodel',...
   'maxTrainSize', 'num_submodel','flag_split_train_test',...
   'flag_standardize','verbose','lambda','svm_theta_solver','mu_pos','mu_neg','classPrior','r1'},...
  {train_test_rate, [],  [],  [], [], [],       [],   [], flag_split_train_test,...
    flag_standardize,verbose,lambda,svm_theta_solver,mu_pos,mu_neg,classPrior,r1});


% 0.2 check whether  arg.flag_split_train_test  is compatible with the input number of file names
if length(varargin_par)==2 && arg.flag_split_train_test==2 % arg.flag_split_train_test = 0, 1 or 2
	error('Provide train file and test file in the setting arg.flag_split_train_test==2');
elseif length(varargin_par)==3 
    arg.flag_split_train_test=2;
    %%%error('Provide the data file directly in the setting arg.flag_split_train_test==1');
end

% 0.3 check whether the data file exist
if length(varargin_par)==2
    % check matDataFile
    [pathstr_user] = fileparts(matDataFile);
    if isempty(pathstr_user) % there is no file path contained in the dataFile name
        matDataFile = [ addFileSep(path_foapl_data) matDataFile];
    end
    if ~exist(matDataFile,'file')
        error('C-Ranker do not find the data file: %s',matDataFile);
    end
elseif length(varargin_par)==3
    % check trainFile
    [pathstr_user] = fileparts(trainFile);
    if isempty(pathstr_user) % there is no file path contained in the dataFile name
        trainFile = [ addFileSep(path_foapl_data) trainFile];
    end
    if ~exist(trainFile,'file')
        error('C-Ranker do not find the data file: %s',trainFile);
    end
    % check testFile
    [pathstr_user] = fileparts(testFile);
    if isempty(pathstr_user) % there is no file path contained in the dataFile name
        testFile = [ addFileSep(path_foapl_data) testFile];
    end
    if ~exist(testFile,'file')
        error('C-Ranker do not find the data file: %s',testFile);
    end
end
    
% 0.4 check and reset matScoreFile
[pathstr_user, name,ext] = fileparts(matScoreFile);
if isempty(pathstr_user) % there is no file path contained in the dataFile name
	matScoreFile = [addFileSep(path_foapl_data) name '.mat'];
else 
    if ~strcmp(ext,'.mat')        
        matScoreFile = [addFileSep(pathstr_user) name '.mat'];
        if arg.verbose>0
            warning('The output data file has been changed to mat file: %s',matDataFile);
        end
    end
end


if arg.verbose>=3
    fwritef(1,'arg',arg,'');
end

% 1. split the total samples to train and test set
if arg.flag_split_train_test
    if arg.flag_split_train_test~= 2 % arg.flag_split_train_test = 0, 1 or 2
        [trainFile,testFile] = foapl_split(matDataFile,...
            'train_test_rate',arg.train_test_rate,...
            'flag_standardize',arg.flag_standardize);
    % else arg.flag_split_train_test== 2: trainFile and testFile are supplied by the user  
    end
    % get ind_train and ind_test
    load(trainFile,'ind');
    ind_train = ind;
    load(testFile,'ind');
    ind_test = ind;    
    clear('ind');
else % do not separate train and test set    
    testFile = '';
      % set train file name
    [pathstr, name] = fileparts(matDataFile);
    if isempty(pathstr) % the user set the file path    
        pathstr = path_foapl_data;      
    end    
    trainFile = [addFileSep(pathstr) name '_train_' datestr(date) '.mat'];
      % standardize the data matrix
    load(matDataFile,'data');
    if arg.flag_standardize
        data.input = standardize(data.input);
    end
      % save the data to another mat file
    [n_sample,n_feature]= size(data.input);    
    saveData(trainFile,'X',data.input,'y',data.output,...
        'sizeX',[n_sample n_feature],'ind',(1:n_sample)',...
        'X_feature',data.input_feature);
    clear('data');
    ind_train = (1:n_sample)';     
    ind_test = [];
end

% 2. train the model
timestamp = datestr(now);
% [model,score_train,weight,ite_inf]= foapl_train(trainFile,...    
%     'flag_w',arg.flag_w,'weight_xcorr',arg.weight_xcorr, 'c1', arg.c1, 'c2',arg.c2,...
%     'return_submodel', arg.return_submodel,...
%     'maxTrainSize', arg.maxTrainSize, 'num_submodel', arg.num_submodel);
[model,score_train,weight,ite_inf]= foapl_train(trainFile,...    
    'r1',arg.r1, 'lambda', arg.lambda,...
    'classPrior', arg.classPrior,'verbose',arg.verbose, ...
     'return_submodel', arg.return_submodel,...
     'maxTrainSize', arg.maxTrainSize, 'num_submodel', arg.num_submodel,...
    'svm_theta_solver', arg.svm_theta_solver, 'mu_pos', arg.mu_pos,  'mu_neg',arg.mu_neg);



% 3. the scores on test set
if arg.flag_split_train_test     
    arg.w = weight.w; 
    [score_test]= foapl_test(model,trainFile,testFile,arg.w,...
        'return_submodel',arg.return_submodel);
else
    score_test = [];
end

% 4.1 save scores,  models and the iteration information to matScoreFile
save(matScoreFile,'score_train','score_test', 'ind_train','ind_test','weight','arg','model','timestamp','ite_inf');
    % save these vairables for the usage of foapl_write()
    
% 4.2 delete train and test file
if arg.flag_split_train_test ~=2
    if exist(trainFile,'file')
        delete(trainFile);
    end
    if exist(testFile,'file');
        delete(testFile);
    end
end

end
