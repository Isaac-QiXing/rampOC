function [score_test]= foapl_test(model,trainFile,testFile,w,varargin)
% calculate the scores on test set based on the trained model(s)
%
% Inputs:
%   model: a trained model of C-Ranker;
%   trainFile: name of a Matlab data file which stores samples in train set;
%   testFile: name of a Matlab data file which stores samples in test set;
%   w: a column vector consisting of the feature weights;
%   varargin: the names and values of arguments of for training the C-Ranker
%           model;
%    varargin{2*i-1}: a string, the argument name;
%    varargin{2*i}: the argument value of varargin{2*i-1}; for i=1, 2, ...
%    the optional arguments are as follows:
%       'return_submodel': 1 or 0, whether return the scores of submodels;
%          default value:  problemArg('return_submodel'); 
%       if 1,
%           SCORE_TEST is a n-by-(q+1) matrix, where n is the number of 
%             samples in test set; q is the number of submodels;
%             the 1st column stores the scores produced by the final
%             combined model, 2-- q+1 columns store the scores produced by
%             the submodels; 
%       if 0,
%           SCORE_TEST is a column vector consisting of the scores produced
%           by the final combined model;
%
% Outputs:
%   score_test: a column vector consisting of the scores of samples in test
%   set;

% arguments
arg = [];
len_arg = length(varargin); 
if len_arg>0
    arg = assignStruct('', varargin(1:2:len_arg),varargin(2:2:len_arg));
end
[kernelType,r1,return_submodel] =...
    problemArg('kernelType','r1','return_submodel');
arg = completeArg(arg,{'return_submodel'},{return_submodel});

argScore = struct('trainFile',trainFile,'testFile',testFile,...
        'kernelType',kernelType, 'r1', r1,'w',w, ...
        'flagOutput','test');
if arg.return_submodel
    argScore.flagOutput = 'test+';
end    
    
score_test = calulate_score(model,argScore);

end