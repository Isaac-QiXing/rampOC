function  foapl_pu_training_file(matTrainFile,matTrainFile_pu,classPrior)
% make pu training file
% Inputs:
%  matTrainFile: mat train file name, containg the training samples and  labels
%  matTrainFile_pu: mat train file name for pu learning.
%  classPrior: a constant sclar in (0,1) in dicating the ratio of the
%      positive distribution among the missing labels
%  
%
%   Both of files  contain the following variables:
%       X: a matrix, each row consists a record/sample;
%       y: a column vector with length as same number of rows of X,
%          consisting of the labels of the samples;
%     ind: a column vectore with same length as y, indexing the samples;
%   sizeX: a 1-by-2 vector, the size of matrix X;
%  X_feature: a string cell array, with the i-th element  the
%           feature name of the i-th column of the matrix X;  default {}

verbose = 1;

data_st = load(matTrainFile);

% % %     % generate labels of PU-learning instances and save train data
% % %     if ~flag_classical_classification
% % %         [y_pu, ii_train] =  pu_label(y_train,classPrior);
% % %     else % classical classification
% % %         y_pu = y_train;
% % %         ii_train = 1:length(y_train);
% % %     end

% % % [path_str,dataset] = fileparts(matTrainFile);
% % % path_str =  addFileSep(path_str);
% % % matTrainFile_pu = sprintf('%s%s_train_pu.mat',path_str,dataset);

[y_pu, ii_train] =  pu_label(data_st.y,classPrior);

userSetting({'classPrior',classPrior});

saveData(matTrainFile_pu,'X',data_st.X(ii_train,:),'y',y_pu,...
    'sizeX',size(data_st.X),'ind', data_st.ind(ii_train), 'X_feature',{});
if verbose>0
    fwritef(1,'#positive instance for training:',nnz(y_pu==1),'',  '#unlabeled instances for training:',nnz(y_pu==-1),'');
end

end